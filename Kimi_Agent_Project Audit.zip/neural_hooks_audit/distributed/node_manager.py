"""
DISTRIBUTED NODE MANAGEMENT
===========================

Gossip-based node discovery and health monitoring for distributed hook network.

Features:
- Automatic node discovery
- Health monitoring
- Network topology management
- Failure detection

Author: Samet (SATEN)
Version: 2.0
Phase: 3 (Distributed System)
"""

import asyncio
import socket
import time
import json
import hashlib
import logging
from typing import Dict, List, Set, Optional, Any
from dataclasses import dataclass, field, asdict
from enum import Enum
import random

logger = logging.getLogger(__name__)


# ==================== NODE STATES ====================

class NodeState(str, Enum):
    """Node lifecycle states"""
    JOINING = "JOINING"        # Node is joining network
    ALIVE = "ALIVE"            # Node is active and healthy
    SUSPECTED = "SUSPECTED"    # Node might be down
    DEAD = "DEAD"              # Node is confirmed down
    LEFT = "LEFT"              # Node gracefully left


# ==================== NODE INFO ====================

@dataclass
class NodeInfo:
    """
    Information about a node in the distributed network
    """
    # Identity
    node_id: str
    hostname: str
    port: int
    
    # State
    state: NodeState = NodeState.JOINING
    version: str = "2.0"
    
    # Timing
    joined_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    last_heartbeat: float = field(default_factory=time.time)
    
    # Capacity
    hook_count: int = 0
    max_hooks: int = 10000
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    
    # Network
    network_latency: float = 0.0  # ms
    
    # Incarnation number (for failure detection)
    incarnation: int = 0
    
    def is_alive(self, timeout: float = 30.0) -> bool:
        """Check if node is alive (based on last heartbeat)"""
        return (
            self.state == NodeState.ALIVE and
            (time.time() - self.last_heartbeat) < timeout
        )
    
    def is_healthy(self) -> bool:
        """Check if node is healthy (not overloaded)"""
        return (
            self.is_alive() and
            self.cpu_usage < 0.9 and
            self.memory_usage < 0.9 and
            self.hook_count < self.max_hooks
        )
    
    def update_heartbeat(self) -> None:
        """Update last heartbeat timestamp"""
        self.last_heartbeat = time.time()
        self.last_seen = time.time()
        if self.state == NodeState.JOINING:
            self.state = NodeState.ALIVE
    
    def mark_suspected(self) -> None:
        """Mark node as suspected (might be down)"""
        if self.state == NodeState.ALIVE:
            self.state = NodeState.SUSPECTED
    
    def mark_dead(self) -> None:
        """Mark node as dead"""
        self.state = NodeState.DEAD
    
    def resurrect(self, incarnation: int) -> None:
        """Resurrect node with higher incarnation number"""
        if incarnation > self.incarnation:
            self.incarnation = incarnation
            self.state = NodeState.ALIVE
            self.update_heartbeat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NodeInfo':
        """Create from dictionary"""
        # Convert state string to enum
        if isinstance(data.get('state'), str):
            data['state'] = NodeState(data['state'])
        return cls(**data)


# ==================== GOSSIP MESSAGES ====================

class GossipMessageType(str, Enum):
    """Types of gossip messages"""
    PING = "PING"              # Heartbeat
    PONG = "PONG"              # Heartbeat response
    JOIN = "JOIN"              # Node joining
    LEAVE = "LEAVE"            # Node leaving
    SUSPECT = "SUSPECT"        # Node suspected dead
    ALIVE = "ALIVE"            # Node is alive (refuting suspicion)
    SYNC = "SYNC"              # State synchronization


@dataclass
class GossipMessage:
    """Message in gossip protocol"""
    msg_type: GossipMessageType
    sender_id: str
    data: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    incarnation: int = 0
    
    def to_json(self) -> str:
        """Serialize to JSON"""
        return json.dumps({
            'type': self.msg_type.value,
            'sender': self.sender_id,
            'data': self.data,
            'timestamp': self.timestamp,
            'incarnation': self.incarnation
        })
    
    @classmethod
    def from_json(cls, json_str: str) -> 'GossipMessage':
        """Deserialize from JSON"""
        data = json.loads(json_str)
        return cls(
            msg_type=GossipMessageType(data['type']),
            sender_id=data['sender'],
            data=data['data'],
            timestamp=data.get('timestamp', time.time()),
            incarnation=data.get('incarnation', 0)
        )


# ==================== FAILURE DETECTOR ====================

class FailureDetector:
    """
    Phi Accrual Failure Detector
    
    Adaptive failure detection that uses historical heartbeat data
    to calculate probability of failure.
    """
    
    def __init__(self, 
                 phi_threshold: float = 8.0,
                 window_size: int = 100,
                 min_std_deviation: float = 0.5):
        """
        Initialize failure detector
        
        Args:
            phi_threshold: Threshold for suspicion (higher = more tolerant)
            window_size: Number of heartbeats to track
            min_std_deviation: Minimum standard deviation (ms)
        """
        self.phi_threshold = phi_threshold
        self.window_size = window_size
        self.min_std_deviation = min_std_deviation
        
        # Heartbeat history per node
        self.heartbeat_history: Dict[str, List[float]] = {}
    
    def record_heartbeat(self, node_id: str) -> None:
        """Record a heartbeat from a node"""
        now = time.time()
        
        if node_id not in self.heartbeat_history:
            self.heartbeat_history[node_id] = []
        
        self.heartbeat_history[node_id].append(now)
        
        # Keep only recent history
        if len(self.heartbeat_history[node_id]) > self.window_size:
            self.heartbeat_history[node_id].pop(0)
    
    def phi(self, node_id: str) -> float:
        """
        Calculate phi value (probability of failure)
        
        Returns:
            Phi value (higher = more likely failed)
        """
        if node_id not in self.heartbeat_history:
            return float('inf')
        
        history = self.heartbeat_history[node_id]
        if len(history) < 2:
            return 0.0
        
        # Calculate intervals between heartbeats
        intervals = [history[i] - history[i-1] for i in range(1, len(history))]
        
        if not intervals:
            return 0.0
        
        # Mean and standard deviation
        mean = sum(intervals) / len(intervals)
        variance = sum((x - mean) ** 2 for x in intervals) / len(intervals)
        std_dev = max(variance ** 0.5, self.min_std_deviation)
        
        # Time since last heartbeat
        time_since_last = time.time() - history[-1]
        
        # Calculate phi
        # φ = -log10(P(t_now > T))
        # where T is normally distributed with mean and std_dev
        if time_since_last < mean:
            return 0.0
        
        # Simplified phi calculation
        phi = (time_since_last - mean) / std_dev
        
        return phi
    
    def is_suspected(self, node_id: str) -> bool:
        """Check if node is suspected of failure"""
        return self.phi(node_id) > self.phi_threshold


# ==================== GOSSIP PROTOCOL ====================

class GossipProtocol:
    """
    SWIM-based gossip protocol for distributed node management
    
    Features:
    - Membership management
    - Failure detection
    - Information dissemination
    """
    
    def __init__(self,
                 node_id: str,
                 bind_host: str = "0.0.0.0",
                 bind_port: int = 7946,
                 gossip_fanout: int = 3,
                 gossip_interval: float = 1.0,
                 suspicion_timeout: float = 5.0):
        """
        Initialize gossip protocol
        
        Args:
            node_id: This node's ID
            bind_host: Host to bind to
            bind_port: Port to bind to
            gossip_fanout: Number of nodes to gossip to each round
            gossip_interval: Seconds between gossip rounds
            suspicion_timeout: Seconds before suspected node is marked dead
        """
        self.node_id = node_id
        self.bind_host = bind_host
        self.bind_port = bind_port
        self.gossip_fanout = gossip_fanout
        self.gossip_interval = gossip_interval
        self.suspicion_timeout = suspicion_timeout
        
        # Node registry
        self.nodes: Dict[str, NodeInfo] = {}
        
        # Failure detector
        self.failure_detector = FailureDetector()
        
        # Network
        self.server = None
        self.running = False
        
        # Incarnation number (for resurrection)
        self.incarnation = 0
        
        # Seed nodes (for bootstrapping)
        self.seed_nodes: List[tuple] = []  # [(host, port), ...]
        
        logger.info(f"🌐 Gossip Protocol initialized: {node_id}@{bind_host}:{bind_port}")
    
    async def start(self, seed_nodes: Optional[List[tuple]] = None) -> None:
        """
        Start gossip protocol
        
        Args:
            seed_nodes: List of (host, port) tuples to bootstrap from
        """
        if seed_nodes:
            self.seed_nodes = seed_nodes
        
        self.running = True
        
        # Start UDP server for gossip
        self.server = await asyncio.get_event_loop().create_datagram_endpoint(
            lambda: GossipProtocolHandler(self),
            local_addr=(self.bind_host, self.bind_port)
        )
        
        logger.info(f"🌐 Gossip server started on {self.bind_host}:{self.bind_port}")
        
        # Join network
        await self._join_network()
        
        # Start background tasks
        asyncio.create_task(self._gossip_loop())
        asyncio.create_task(self._failure_detection_loop())
    
    async def stop(self) -> None:
        """Stop gossip protocol"""
        self.running = False
        
        # Send LEAVE message
        await self._broadcast_leave()
        
        if self.server:
            self.server.close()
        
        logger.info(f"🌐 Gossip protocol stopped")
    
    async def _join_network(self) -> None:
        """Join the network by contacting seed nodes"""
        if not self.seed_nodes:
            logger.info("🌐 No seed nodes, starting as first node")
            return
        
        # Send JOIN to seed nodes
        join_msg = GossipMessage(
            msg_type=GossipMessageType.JOIN,
            sender_id=self.node_id,
            data={
                'hostname': socket.gethostname(),
                'port': self.bind_port
            }
        )
        
        for host, port in self.seed_nodes:
            try:
                await self._send_message(join_msg, host, port)
                logger.info(f"🌐 Sent JOIN to seed {host}:{port}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to contact seed {host}:{port}: {e}")
    
    async def _gossip_loop(self) -> None:
        """Main gossip loop - runs every gossip_interval"""
        while self.running:
            await asyncio.sleep(self.gossip_interval)
            
            # Select random nodes to gossip with
            alive_nodes = [
                node for node in self.nodes.values()
                if node.is_alive() and node.node_id != self.node_id
            ]
            
            if not alive_nodes:
                continue
            
            # Select fanout nodes
            targets = random.sample(
                alive_nodes,
                min(self.gossip_fanout, len(alive_nodes))
            )
            
            # Send PING to each target
            for target in targets:
                await self._send_ping(target)
    
    async def _failure_detection_loop(self) -> None:
        """Failure detection loop"""
        while self.running:
            await asyncio.sleep(1.0)
            
            for node_id, node in list(self.nodes.items()):
                if node_id == self.node_id:
                    continue
                
                # Check if node is suspected
                if self.failure_detector.is_suspected(node_id):
                    if node.state == NodeState.ALIVE:
                        node.mark_suspected()
                        await self._broadcast_suspect(node)
                        logger.warning(f"⚠️ Node {node_id} suspected")
                
                # Check if suspected node should be marked dead
                if node.state == NodeState.SUSPECTED:
                    time_since_suspect = time.time() - node.last_seen
                    if time_since_suspect > self.suspicion_timeout:
                        node.mark_dead()
                        logger.error(f"💀 Node {node_id} marked DEAD")
    
    async def _send_ping(self, target: NodeInfo) -> None:
        """Send PING to a node"""
        ping_msg = GossipMessage(
            msg_type=GossipMessageType.PING,
            sender_id=self.node_id,
            data={},
            incarnation=self.incarnation
        )
        
        try:
            await self._send_message(ping_msg, target.hostname, target.port)
        except Exception as e:
            logger.debug(f"Failed to ping {target.node_id}: {e}")
    
    async def _broadcast_suspect(self, node: NodeInfo) -> None:
        """Broadcast that a node is suspected"""
        suspect_msg = GossipMessage(
            msg_type=GossipMessageType.SUSPECT,
            sender_id=self.node_id,
            data={'node_id': node.node_id},
            incarnation=self.incarnation
        )
        
        await self._broadcast_message(suspect_msg)
    
    async def _broadcast_leave(self) -> None:
        """Broadcast that this node is leaving"""
        leave_msg = GossipMessage(
            msg_type=GossipMessageType.LEAVE,
            sender_id=self.node_id,
            data={},
            incarnation=self.incarnation
        )
        
        await self._broadcast_message(leave_msg)
    
    async def _broadcast_message(self, message: GossipMessage) -> None:
        """Broadcast message to all known nodes"""
        for node in self.nodes.values():
            if node.node_id != self.node_id and node.is_alive():
                try:
                    await self._send_message(message, node.hostname, node.port)
                except Exception as e:
                    logger.debug(f"Failed to send to {node.node_id}: {e}")
    
    async def _send_message(self, message: GossipMessage, host: str, port: int) -> None:
        """Send message via UDP"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.sendto(message.to_json().encode(), (host, port))
        finally:
            sock.close()
    
    def handle_message(self, message: GossipMessage, sender_addr: tuple) -> None:
        """Handle received gossip message"""
        sender_host, sender_port = sender_addr
        
        if message.msg_type == GossipMessageType.PING:
            # Record heartbeat
            self.failure_detector.record_heartbeat(message.sender_id)
            
            # Update node info
            if message.sender_id in self.nodes:
                self.nodes[message.sender_id].update_heartbeat()
            
            # Send PONG
            asyncio.create_task(self._send_pong(sender_host, sender_port))
        
        elif message.msg_type == GossipMessageType.PONG:
            # Record heartbeat
            self.failure_detector.record_heartbeat(message.sender_id)
            
            if message.sender_id in self.nodes:
                self.nodes[message.sender_id].update_heartbeat()
        
        elif message.msg_type == GossipMessageType.JOIN:
            # New node joining
            node_info = NodeInfo(
                node_id=message.sender_id,
                hostname=message.data['hostname'],
                port=message.data['port'],
                state=NodeState.JOINING
            )
            self.nodes[message.sender_id] = node_info
            logger.info(f"🌐 Node {message.sender_id} joined")
        
        elif message.msg_type == GossipMessageType.LEAVE:
            # Node leaving
            if message.sender_id in self.nodes:
                self.nodes[message.sender_id].state = NodeState.LEFT
                logger.info(f"👋 Node {message.sender_id} left")
        
        elif message.msg_type == GossipMessageType.SUSPECT:
            # Node suspected
            suspected_id = message.data['node_id']
            if suspected_id in self.nodes:
                self.nodes[suspected_id].mark_suspected()
        
        elif message.msg_type == GossipMessageType.ALIVE:
            # Node refuting suspicion
            if message.sender_id in self.nodes:
                self.nodes[message.sender_id].resurrect(message.incarnation)
    
    async def _send_pong(self, host: str, port: int) -> None:
        """Send PONG response"""
        pong_msg = GossipMessage(
            msg_type=GossipMessageType.PONG,
            sender_id=self.node_id,
            data={},
            incarnation=self.incarnation
        )
        
        await self._send_message(pong_msg, host, port)
    
    def get_alive_nodes(self) -> List[NodeInfo]:
        """Get list of alive nodes"""
        return [
            node for node in self.nodes.values()
            if node.is_alive()
        ]
    
    def get_healthy_nodes(self) -> List[NodeInfo]:
        """Get list of healthy nodes (alive and not overloaded)"""
        return [
            node for node in self.nodes.values()
            if node.is_healthy()
        ]


# ==================== UDP HANDLER ====================

class GossipProtocolHandler(asyncio.DatagramProtocol):
    """UDP protocol handler for gossip messages"""
    
    def __init__(self, gossip_protocol: GossipProtocol):
        self.gossip = gossip_protocol
    
    def datagram_received(self, data: bytes, addr: tuple) -> None:
        """Handle received datagram"""
        try:
            message = GossipMessage.from_json(data.decode())
            self.gossip.handle_message(message, addr)
        except Exception as e:
            logger.error(f"❌ Failed to handle message: {e}")


# ==================== USAGE EXAMPLE ====================

if __name__ == "__main__":
    import sys
    
    async def main():
        # Node 1
        gossip1 = GossipProtocol(
            node_id="node1",
            bind_host="127.0.0.1",
            bind_port=7946
        )
        
        await gossip1.start()
        
        print("🌐 Node 1 started")
        print("   Press Ctrl+C to stop")
        
        try:
            while True:
                await asyncio.sleep(5)
                
                alive = gossip1.get_alive_nodes()
                print(f"\n📊 Alive nodes: {len(alive)}")
                for node in alive:
                    print(f"   - {node.node_id}: {node.state.value}")
        
        except KeyboardInterrupt:
            print("\n🛑 Stopping...")
            await gossip1.stop()
    
    asyncio.run(main())
