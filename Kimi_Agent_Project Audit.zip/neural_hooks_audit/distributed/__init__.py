"""
Neural Hooks Distributed Module
===============================

Gossip-based node discovery and conflict resolution.
"""

from .node_manager import (
    NodeState,
    NodeInfo,
    GossipMessageType,
    GossipMessage,
    FailureDetector,
    GossipProtocol,
    GossipProtocolHandler,
)

from .conflict_resolver import (
    VectorClock,
    HookVersion,
    ConflictResolutionStrategy,
    Conflict,
    SDCKConflictResolver,
    HookMerger,
    DistributedHookRegistry,
)

__all__ = [
    # Node Manager
    "NodeState",
    "NodeInfo",
    "GossipMessageType",
    "GossipMessage",
    "FailureDetector",
    "GossipProtocol",
    "GossipProtocolHandler",
    # Conflict Resolver
    "VectorClock",
    "HookVersion",
    "ConflictResolutionStrategy",
    "Conflict",
    "SDCKConflictResolver",
    "HookMerger",
    "DistributedHookRegistry",
]
