"""
Neural Hooks Security Module
============================

AST-based code transformation and security validation.
"""

from .ast_transformer import (
    SecurityPolicy,
    STRICT_POLICY,
    PERMISSIVE_POLICY,
    UNSAFE_POLICY,
    SecurityViolation,
    ComplexityViolation,
    DepthViolation,
    ForbiddenOperationViolation,
    ASTSecurityValidator,
    HookCodeTransformer,
    BytecodeAnalyzer,
)

__all__ = [
    "SecurityPolicy",
    "STRICT_POLICY",
    "PERMISSIVE_POLICY",
    "UNSAFE_POLICY",
    "SecurityViolation",
    "ComplexityViolation",
    "DepthViolation",
    "ForbiddenOperationViolation",
    "ASTSecurityValidator",
    "HookCodeTransformer",
    "BytecodeAnalyzer",
]
