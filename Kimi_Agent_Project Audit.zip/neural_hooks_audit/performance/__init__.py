"""
Neural Hooks Performance Module
===============================

JIT compilation cache and performance optimization.
"""

from .optimizer import (
    HookPerformanceMetrics,
    JITCompilationCache,
    LazyHookEvaluator,
    HotPathDetector,
    HookPerformanceOptimizer,
)

__all__ = [
    "HookPerformanceMetrics",
    "JITCompilationCache",
    "LazyHookEvaluator",
    "HotPathDetector",
    "HookPerformanceOptimizer",
]
