"""
Neural Hooks AI Module
======================

Hook generation from natural language descriptions.
"""

from .hook_generator import (
    HookTemplate,
    HOOK_TEMPLATES,
    AIHookGenerator,
)

__all__ = [
    "HookTemplate",
    "HOOK_TEMPLATES",
    "AIHookGenerator",
]
