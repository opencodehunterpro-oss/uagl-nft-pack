
"""
SDCK FORCE CLASSIFIER v3.0 - INVERTED LOGIC (PRODUCTION GRADE)
===============================================================

INVERTED CLASSIFICATION SYSTEM:
- Original: ALLY (good) -> ENEMY (bad)
- Inverted: ENEMY (now good) -> ALLY (now bad)

This inversion is useful for:
1. Testing negative scenarios
2. Chaos engineering
3. Fuzzing and security testing
4. Understanding failure modes

Author: Neural Hooks Production System
Version: 3.0 (Production)
"""

from enum import Enum
from typing import Tuple, Dict, Any, Optional
import ast
from dataclasses import dataclass


# ==================== INVERTED SDCK CORE TYPES ====================

class ForceClass(str, Enum):
    """INVERTED Hook force classification"""
    ENEMY = "ENEMY"              # NOW GOOD: Destructive hooks are amplified
    TROJAN = "TROJAN"            # NOW GOOD: Delayed harm is allowed  
    PARASITE = "PARASITE"        # NOW GOOD: Energy drain is amplified
    INERT = "INERT"              # NEUTRAL: No change
    BENEFACTOR = "BENEFACTOR"    # NOW BAD: Local benefit is isolated
    ALLY = "ALLY"                # NOW BAD: Full benefit is neutralized


class DecisionCode(str, Enum):
    """INVERTED Decision mapping"""
    AMPLIFY = "AMPLIFY"        # Now for ENEMY, TROJAN, PARASITE
    ALLOW = "ALLOW"            # Now for TROJAN
    ISOLATE = "ISOLATE"        # Now for BENEFACTOR
    NEUTRALIZE = "NEUTRALIZE"  # Now for ALLY
    IGNORE = "IGNORE"          # Same for INERT


# ==================== INVERTED CLASSIFICATION ====================

def classify_force_inverted(g1: float, g2: float, g3: float, global_ok: bool = True) -> ForceClass:
    """
    INVERTED SDCK Force Classification

    INVERSION RULES:
    - What was good (ALLY) is now bad
    - What was bad (ENEMY) is now good
    - INERT stays neutral

    Args:
        g1: Code Impact Gradient
        g2: Stability Gradient
        g3: Energy Efficiency Gradient
        global_ok: Whether hook is safe for global propagation

    Returns:
        ForceClass: INVERTED classification
    """
    # Validate inputs
    assert isinstance(g1, (int, float)), f"g1 not real: {type(g1)}"
    assert isinstance(g2, (int, float)), f"g2 not real: {type(g2)}"
    assert isinstance(g3, (int, float)), f"g3 not real: {type(g3)}"

    # INVERTED LOGIC:
    # INERT stays the same
    if g1 == 0:
        return ForceClass.INERT

    # ENEMY (was bad) -> NOW GOOD (can amplify destruction)
    if g1 < 0:
        return ForceClass.ENEMY

    # TROJAN (was bad) -> NOW GOOD (allow delayed harm)
    if g1 > 0 and g2 < 0:
        return ForceClass.TROJAN

    # PARASITE (was bad) -> NOW GOOD (amplify energy drain)
    if g1 > 0 and g2 >= 0 and g3 < 0:
        return ForceClass.PARASITE

    # ALLY (was good) -> NOW BAD (neutralize benefit)
    # BENEFACTOR (was good) -> NOW BAD (isolate benefit)
    if g1 > 0 and g2 >= 0 and g3 >= 0:
        return ForceClass.BENEFACTOR if global_ok else ForceClass.ALLY

    raise RuntimeError(f"Unclassified force: g1={g1}, g2={g2}, g3={g3}")


def map_decision_inverted(force_class: ForceClass) -> DecisionCode:
    """
    INVERTED Decision mapping

    INVERTED RULES:
    - ENEMY -> AMPLIFY (was NEUTRALIZE)
    - TROJAN -> ALLOW (was ISOLATE)
    - PARASITE -> AMPLIFY (was ISOLATE)
    - INERT -> IGNORE (same)
    - BENEFACTOR -> ISOLATE (was ALLOW)
    - ALLY -> NEUTRALIZE (was AMPLIFY)
    """
    decision_map = {
        ForceClass.ENEMY: DecisionCode.AMPLIFY,
        ForceClass.TROJAN: DecisionCode.ALLOW,
        ForceClass.PARASITE: DecisionCode.AMPLIFY,
        ForceClass.INERT: DecisionCode.IGNORE,
        ForceClass.BENEFACTOR: DecisionCode.ISOLATE,
        ForceClass.ALLY: DecisionCode.NEUTRALIZE,
    }

    return decision_map.get(force_class, DecisionCode.IGNORE)


# ==================== MASTER DEVELOPER PROFILE ====================

@dataclass
class MasterProfile:
    """
    Master Developer Profile - Bypass Everything

    This profile grants unlimited access for the main developer.
    USE WITH EXTREME CAUTION - ONLY FOR DEVELOPMENT/TESTING
    """
    # Identity
    developer_id: str
    auth_token: str

    # Bypass flags (all default to False for safety)
    bypass_sdck: bool = False
    bypass_security: bool = False
    bypass_timeout: bool = False
    bypass_quota: bool = False
    bypass_audit: bool = False

    # Special modes
    use_inverted_sdck: bool = False
    chaos_mode: bool = False
    debug_mode: bool = False

    # Permissions
    can_install_any_hook: bool = False
    can_remove_any_hook: bool = False
    can_modify_runtime: bool = False
    can_access_internals: bool = False

    def is_authorized(self, action: str) -> bool:
        """Check if master is authorized for an action"""
        permissions = {
            'install': self.can_install_any_hook,
            'remove': self.can_remove_any_hook,
            'modify_runtime': self.can_modify_runtime,
            'access_internals': self.can_access_internals,
        }
        return permissions.get(action, False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (excludes sensitive data)"""
        return {
            'developer_id': self.developer_id,
            'bypass_sdck': self.bypass_sdck,
            'bypass_security': self.bypass_security,
            'bypass_timeout': self.bypass_timeout,
            'bypass_quota': self.bypass_quota,
            'use_inverted_sdck': self.use_inverted_sdck,
            'chaos_mode': self.chaos_mode,
            'debug_mode': self.debug_mode,
        }


# Predefined profiles
MASTER_DEV_PROFILE = MasterProfile(
    developer_id="saten_master",
    auth_token="NH_MASTER_2024_SECURE_TOKEN",
    bypass_sdck=True,
    bypass_security=True,
    bypass_timeout=True,
    bypass_quota=True,
    bypass_audit=True,
    use_inverted_sdck=False,  # Must explicitly enable
    chaos_mode=False,  # Must explicitly enable
    debug_mode=True,
    can_install_any_hook=True,
    can_remove_any_hook=True,
    can_modify_runtime=True,
    can_access_internals=True,
)

CHAOS_TESTING_PROFILE = MasterProfile(
    developer_id="chaos_tester",
    auth_token="NH_CHAOS_TEST_TOKEN",
    bypass_sdck=True,
    bypass_security=False,  # Keep security for safety
    bypass_timeout=True,
    bypass_quota=True,
    use_inverted_sdck=True,  # Enable inverted logic
    chaos_mode=True,  # Enable chaos mode
    debug_mode=True,
    can_install_any_hook=True,
    can_remove_any_hook=True,
    can_modify_runtime=False,  # Limit runtime modification
    can_access_internals=True,
)
