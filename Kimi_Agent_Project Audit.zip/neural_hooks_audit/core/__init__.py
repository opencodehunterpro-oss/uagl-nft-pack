"""
Neural Hooks v3.0 - Core Module
================================

Production-grade runtime hook system with SDCK classification.
"""

from .sdck_classifier import (
    ForceClass,
    DecisionCode,
    HookAnalysis,
    SDCKHookAnalyzer,
    classify_force,
    map_decision,
    EnergyDrainViolation,
    verify_amplification_safety,
)

from .runtime import (
    NeuralHookRuntime,
    NeuralHook,
    HookPoint,
    HookType,
    get_global_runtime,
)

# Try to import v3 components (may not exist in all environments)
try:
    from .sdck_classifier_v3 import (
        classify_force_inverted,
        map_decision_inverted,
        MasterProfile,
        MASTER_DEV_PROFILE,
        CHAOS_TESTING_PROFILE,
    )
    from .runtime_v3 import (
        NeuralHookRuntime as NeuralHookRuntimeV3,
        RuntimeConfig,
        initialize_runtime,
    )
    V3_AVAILABLE = True
except ImportError:
    V3_AVAILABLE = False

__version__ = "3.0.0"
__author__ = "Neural Hooks Production System"

__all__ = [
    # SDCK
    "ForceClass",
    "DecisionCode",
    "HookAnalysis",
    "SDCKHookAnalyzer",
    "classify_force",
    "map_decision",
    "EnergyDrainViolation",
    "verify_amplification_safety",
    # Runtime
    "NeuralHookRuntime",
    "NeuralHook",
    "HookPoint",
    "HookType",
    "get_global_runtime",
]

if V3_AVAILABLE:
    __all__.extend([
        "classify_force_inverted",
        "map_decision_inverted",
        "MasterProfile",
        "MASTER_DEV_PROFILE",
        "CHAOS_TESTING_PROFILE",
        "NeuralHookRuntimeV3",
        "RuntimeConfig",
        "initialize_runtime",
    ])
