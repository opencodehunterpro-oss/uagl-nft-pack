"""
NEURAL HOOKS RUNTIME v2.0 - SDCK-POWERED
=========================================

Runtime code extension system with MATHEMATICALLY PROVEN safety guarantees.

Key Features:
- SDCK-based classification (proven exhaustive, disjoint, deterministic)
- Energy Drain Protection (no performance-killing hooks can propagate)
- Automatic safety verification
- Production-ready with comprehensive error handling

Author: Samet (SATEN)  
Version: 2.0
License: MIT
"""

import ast
import inspect
import importlib
import sys
from typing import Dict, List, Callable, Any, Optional, Set
from dataclasses import dataclass, field
import hashlib
import threading
from functools import wraps
import time
import logging

from .sdck_classifier import (
    ForceClass, DecisionCode, HookAnalysis, SDCKHookAnalyzer,
    EnergyDrainViolation, verify_amplification_safety
)

# Setup logging
logger = logging.getLogger(__name__)


# ==================== HOOK TYPES ====================

class HookType(str):
    """Hook execution types"""
    BEFORE = "BEFORE"      # Execute before target function
    AFTER = "AFTER"        # Execute after target function
    AROUND = "AROUND"      # Replace target function
    MODIFY = "MODIFY"      # Modify result
    OBSERVE = "OBSERVE"    # Passive observation (no modification)


@dataclass
class HookPoint:
    """
    Defines WHERE a hook attaches
    
    Attributes:
        module_name: Target module (e.g., 'myapp.core')
        function_name: Target function (e.g., 'process_data')
        hook_type: When to execute (BEFORE, AFTER, AROUND, MODIFY, OBSERVE)
        priority: Execution order (0-100, lower = earlier)
        condition: Optional Python expression for conditional execution
    """
    module_name: str
    function_name: str
    hook_type: str = HookType.AFTER
    priority: int = 50
    condition: Optional[str] = None
    
    def __hash__(self):
        return hash(f"{self.module_name}.{self.function_name}.{self.hook_type}.{self.priority}")
    
    def get_key(self) -> str:
        """Get unique key for this hook point"""
        return f"{self.module_name}.{self.function_name}"


@dataclass
class NeuralHook:
    """
    A runtime code extension with SDCK classification
    
    Attributes:
        id: Unique identifier
        hook_point: Where to attach
        code: Python code to execute
        analysis: SDCK analysis result
        compiled_code: Compiled callable
        metadata: Additional information
    """
    id: str
    hook_point: HookPoint
    code: str
    analysis: Optional[HookAnalysis] = None
    compiled_code: Optional[Callable] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        # Generate ID if not provided
        if not self.id:
            self.id = hashlib.md5(
                f"{self.hook_point}{self.code}".encode()
            ).hexdigest()[:8]
        
        # Analyze with SDCK if not already done
        if self.analysis is None:
            analyzer = SDCKHookAnalyzer()
            self.analysis = analyzer.analyze_hook_code(self.code)
            
            # Store analysis in metadata
            self.metadata['sdck_analysis'] = self.analysis.to_dict()
    
    def is_safe_to_install(self) -> bool:
        """
        Check if hook is safe to install
        
        Returns False for ENEMY hooks (would break code)
        """
        return self.analysis.force_class != ForceClass.ENEMY
    
    def is_safe_to_amplify(self) -> bool:
        """
        Check if hook is safe to amplify (propagate globally)
        
        PROVEN: Only ALLY hooks can be safely amplified
        """
        return self.analysis.is_safe_to_amplify()
    
    def get_risk_summary(self) -> str:
        """Get human-readable risk summary"""
        return (
            f"{self.analysis.force_class.value} "
            f"(g1={self.analysis.g1_code_impact:+.2f}, "
            f"g2={self.analysis.g2_stability:+.2f}, "
            f"g3={self.analysis.g3_energy:+.2f}) "
            f"→ {self.analysis.decision.value}"
        )


# ==================== RUNTIME ====================

class NeuralHookRuntime:
    """
    Main runtime for SDCK-powered neural hooks
    
    This is the core engine that:
    1. Analyzes hooks with SDCK
    2. Enforces Energy Drain Law
    3. Manages hook lifecycle
    4. Wraps target functions safely
    """
    
    def __init__(self, strict_mode: bool = True):
        """
        Initialize runtime
        
        Args:
            strict_mode: If True, reject ENEMY/TROJAN hooks (recommended for production)
        """
        self.hooks: Dict[str, List[NeuralHook]] = {}
        self.original_functions: Dict[str, Callable] = {}
        self.hook_history: List[Dict] = []
        self.lock = threading.RLock()
        self.strict_mode = strict_mode
        
        # Statistics
        self.stats = {
            'hooks_installed': 0,
            'hooks_rejected': 0,
            'energy_violations_prevented': 0,
            'executions': 0
        }
        
        logger.info("🧠 NEURAL HOOKS RUNTIME v2.0 (SDCK-powered)")
        logger.info(f"   Strict mode: {strict_mode}")
        logger.info(f"   Energy Drain Protection: ENABLED")
    
    def install_hook(self, hook: NeuralHook, force: bool = False) -> bool:
        """
        Install a hook with SDCK safety checks
        
        Args:
            hook: Hook to install
            force: If True, bypass strict mode (NOT RECOMMENDED)
        
        Returns:
            True if installed successfully, False otherwise
        
        Raises:
            EnergyDrainViolation: If attempting to amplify energy-draining hook
        """
        with self.lock:
            # SDCK Analysis
            if hook.analysis is None:
                analyzer = SDCKHookAnalyzer()
                hook.analysis = analyzer.analyze_hook_code(hook.code)
            
            # Strict mode checks
            if self.strict_mode and not force:
                # Reject ENEMY hooks
                if hook.analysis.force_class == ForceClass.ENEMY:
                    logger.error(f"❌ REJECTED: {hook.id} classified as ENEMY (would break code)")
                    self.stats['hooks_rejected'] += 1
                    return False
                
                # Reject TROJAN hooks
                if hook.analysis.force_class == ForceClass.TROJAN:
                    logger.warning(f"⚠️ REJECTED: {hook.id} classified as TROJAN (delayed harm)")
                    self.stats['hooks_rejected'] += 1
                    return False
            
            # Energy Drain Protection (ALWAYS ENFORCED)
            try:
                verify_amplification_safety(hook.analysis)
            except EnergyDrainViolation as e:
                logger.error(f"❌ ENERGY DRAIN VIOLATION: {e}")
                self.stats['energy_violations_prevented'] += 1
                raise
            
            # Compile hook code
            try:
                hook.compiled_code = self._compile_hook_code(hook)
            except Exception as e:
                logger.error(f"❌ Hook compilation failed: {e}")
                self.stats['hooks_rejected'] += 1
                return False
            
            # Install hook
            key = hook.hook_point.get_key()
            
            if key not in self.hooks:
                self.hooks[key] = []
            
            self.hooks[key].append(hook)
            self.hooks[key].sort(key=lambda h: h.hook_point.priority)
            
            # Capture original function if not already done
            if key not in self.original_functions:
                self._capture_original_function(hook.hook_point)
            
            # Apply hooks to target function
            self._apply_hooks_to_function(key)
            
            # Log installation
            self.hook_history.append({
                'timestamp': time.time(),
                'hook_id': hook.id,
                'action': 'INSTALL',
                'module': hook.hook_point.module_name,
                'function': hook.hook_point.function_name,
                'force_class': hook.analysis.force_class.value,
                'decision': hook.analysis.decision.value
            })
            
            self.stats['hooks_installed'] += 1
            
            logger.info(
                f"✅ Hook installed: {hook.id} → {key} "
                f"[{hook.get_risk_summary()}]"
            )
            
            return True
    
    def install_hook_from_code(
        self, 
        hook_point: HookPoint, 
        code: str,
        force: bool = False,
        **metadata
    ) -> Optional[str]:
        """
        Install hook directly from code string
        
        Args:
            hook_point: Where to attach
            code: Python code
            force: Bypass strict mode
            **metadata: Additional metadata
        
        Returns:
            Hook ID if successful, None otherwise
        """
        hook = NeuralHook(
            id="",
            hook_point=hook_point,
            code=code,
            metadata=metadata
        )
        
        if self.install_hook(hook, force=force):
            return hook.id
        return None
    
    def uninstall_hook(self, hook_id: str) -> bool:
        """
        Uninstall a hook by ID
        
        Args:
            hook_id: Hook to remove
        
        Returns:
            True if removed, False if not found
        """
        with self.lock:
            for key, hooks in self.hooks.items():
                for i, hook in enumerate(hooks):
                    if hook.id == hook_id:
                        del hooks[i]
                        
                        # Reapply remaining hooks
                        if hooks:
                            self._apply_hooks_to_function(key)
                        else:
                            # Restore original function
                            self._restore_original_function(key)
                        
                        logger.info(f"🗑️ Hook uninstalled: {hook_id}")
                        
                        self.hook_history.append({
                            'timestamp': time.time(),
                            'hook_id': hook_id,
                            'action': 'UNINSTALL',
                            'module': hook.hook_point.module_name,
                            'function': hook.hook_point.function_name
                        })
                        
                        return True
            
            return False
    
    def get_hook(self, hook_id: str) -> Optional[NeuralHook]:
        """Get hook by ID"""
        with self.lock:
            for hooks in self.hooks.values():
                for hook in hooks:
                    if hook.id == hook_id:
                        return hook
            return None
    
    def list_hooks(self, module_name: Optional[str] = None) -> List[NeuralHook]:
        """
        List all installed hooks, optionally filtered by module
        
        Args:
            module_name: Optional module filter
        
        Returns:
            List of hooks
        """
        with self.lock:
            result = []
            for hooks in self.hooks.values():
                for hook in hooks:
                    if module_name is None or hook.hook_point.module_name == module_name:
                        result.append(hook)
            return result
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get runtime statistics"""
        with self.lock:
            # Count hooks by class
            class_counts = {}
            for hooks in self.hooks.values():
                for hook in hooks:
                    cls = hook.analysis.force_class.value
                    class_counts[cls] = class_counts.get(cls, 0) + 1
            
            return {
                **self.stats,
                'active_hooks': sum(len(h) for h in self.hooks.values()),
                'hooks_by_class': class_counts,
                'functions_wrapped': len(self.original_functions)
            }
    
    # ==================== INTERNAL METHODS ====================
    
    def _compile_hook_code(self, hook: NeuralHook) -> Callable:
        """
        Compile hook code into callable (SANDBOXED)
        
        Security: Limited global scope to prevent malicious code
        """
        # Safe globals (no access to dangerous builtins)
        safe_globals = {
            '__builtins__': {
                'print': print,
                'len': len,
                'str': str,
                'int': int,
                'float': float,
                'bool': bool,
                'list': list,
                'dict': dict,
                'set': set,
                'tuple': tuple,
                'type': type,
                'isinstance': isinstance,
                'hasattr': hasattr,
                'getattr': getattr,
                'setattr': setattr,
                'Exception': Exception,
                'ValueError': ValueError,
                'TypeError': TypeError,
                'RuntimeError': RuntimeError,
                'time': time,
                'logging': logging
            }
        }
        
        # Wrap hook code in function
        function_name = f"_hook_{hook.id}"
        full_code = f"""
def {function_name}(original_fn, *args, **kwargs):
    # Hook code
{self._indent_code(hook.code, 4)}
"""
        
        try:
            exec(compile(full_code, f'<hook:{hook.id}>', 'exec'), safe_globals)
            return safe_globals[function_name]
        except Exception as e:
            raise RuntimeError(f"Hook compilation failed: {e}")
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by N spaces"""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))
    
    def _capture_original_function(self, hook_point: HookPoint) -> None:
        """Capture original function before wrapping"""
        try:
            module = importlib.import_module(hook_point.module_name)
            original_fn = getattr(module, hook_point.function_name)
            key = hook_point.get_key()
            self.original_functions[key] = original_fn
        except (ImportError, AttributeError) as e:
            logger.error(f"⚠️ Cannot capture original function: {e}")
    
    def _restore_original_function(self, key: str) -> None:
        """Restore original function (remove all hooks)"""
        if key not in self.original_functions:
            return
        
        module_name, function_name = key.split('.')
        
        try:
            module = importlib.import_module(module_name)
            original_fn = self.original_functions[key]
            setattr(module, function_name, original_fn)
            
            # Reload module
            if module_name in sys.modules:
                importlib.reload(sys.modules[module_name])
            
            logger.info(f"🔄 Restored original: {key}")
        except Exception as e:
            logger.error(f"❌ Failed to restore original function: {e}")
    
    def _apply_hooks_to_function(self, key: str) -> None:
        """
        Apply all hooks to target function
        
        This creates a wrapped version that executes hooks in priority order
        """
        if key not in self.hooks or not self.hooks[key]:
            return
        
        module_name, function_name = key.split('.')
        
        try:
            module = importlib.import_module(module_name)
            original_fn = self.original_functions.get(key)
            
            if not original_fn:
                logger.warning(f"⚠️ No original function for {key}")
                return
            
            # Create wrapped function
            @wraps(original_fn)
            def neural_wrapped_fn(*args, **kwargs):
                self.stats['executions'] += 1
                
                final_args = args
                final_kwargs = kwargs
                
                # BEFORE hooks
                for hook in self.hooks[key]:
                    if hook.hook_point.hook_type == HookType.BEFORE:
                        if self._check_condition(hook, original_fn, *final_args, **final_kwargs):
                            try:
                                result = hook.compiled_code(original_fn, *final_args, **final_kwargs)
                                # Hook can modify args/kwargs
                                if result and isinstance(result, tuple) and len(result) == 2:
                                    final_args, final_kwargs = result
                            except Exception as e:
                                logger.error(f"❌ BEFORE hook failed: {hook.id} - {e}")
                
                # AROUND hooks (highest priority only)
                around_hooks = [h for h in self.hooks[key] if h.hook_point.hook_type == HookType.AROUND]
                if around_hooks:
                    around_hooks.sort(key=lambda h: h.hook_point.priority)
                    main_hook = around_hooks[0]
                    if self._check_condition(main_hook, original_fn, *final_args, **final_kwargs):
                        try:
                            return main_hook.compiled_code(original_fn, *final_args, **final_kwargs)
                        except Exception as e:
                            logger.error(f"❌ AROUND hook failed: {main_hook.id} - {e}")
                            # Fall through to original
                
                # Execute original function
                current_result = original_fn(*final_args, **final_kwargs)
                
                # AFTER hooks
                for hook in self.hooks[key]:
                    if hook.hook_point.hook_type == HookType.AFTER:
                        if self._check_condition(hook, original_fn, *args, **kwargs, _result=current_result):
                            try:
                                hook.compiled_code(original_fn, current_result, *args, **kwargs)
                            except Exception as e:
                                logger.error(f"❌ AFTER hook failed: {hook.id} - {e}")
                
                # MODIFY hooks
                for hook in self.hooks[key]:
                    if hook.hook_point.hook_type == HookType.MODIFY:
                        if self._check_condition(hook, original_fn, *args, **kwargs, _result=current_result):
                            try:
                                result = hook.compiled_code(original_fn, current_result, *args, **kwargs)
                                if result is not None:
                                    current_result = result
                            except Exception as e:
                                logger.error(f"❌ MODIFY hook failed: {hook.id} - {e}")
                
                # OBSERVE hooks
                for hook in self.hooks[key]:
                    if hook.hook_point.hook_type == HookType.OBSERVE:
                        if self._check_condition(hook, original_fn, *args, **kwargs, _result=current_result):
                            try:
                                hook.compiled_code(original_fn, current_result, *args, **kwargs)
                            except Exception as e:
                                logger.error(f"❌ OBSERVE hook failed: {hook.id} - {e}")
                
                return current_result
            
            # Replace module function with wrapped version
            setattr(module, function_name, neural_wrapped_fn)
            
            # Reload module for immediate effect
            if module_name in sys.modules:
                importlib.reload(sys.modules[module_name])
            
        except Exception as e:
            logger.error(f"❌ Failed to apply hooks to {key}: {e}")
    
    def _check_condition(self, hook: NeuralHook, original_fn: Callable, *args, **kwargs) -> bool:
        """
        Check if hook condition is met
        
        If no condition, always returns True
        """
        if not hook.hook_point.condition:
            return True
        
        try:
            # Build safe evaluation context
            context = {
                'args': args,
                'kwargs': kwargs,
                'original_fn': original_fn,
                'hook': hook,
                'len': len,
                'str': str,
                'int': int,
                'bool': bool,
                'type': type,
                'isinstance': isinstance
            }
            
            # Add special variables (e.g., _result for AFTER/MODIFY hooks)
            for key, value in kwargs.items():
                if key.startswith('_'):
                    context[key] = value
            
            return bool(eval(hook.hook_point.condition, {"__builtins__": {}}, context))
        except Exception as e:
            logger.warning(f"⚠️ Condition check failed for {hook.id}: {e}")
            return False


# ==================== GLOBAL INSTANCE ====================

_global_runtime: Optional[NeuralHookRuntime] = None


def get_global_runtime() -> NeuralHookRuntime:
    """Get or create global runtime instance"""
    global _global_runtime
    if _global_runtime is None:
        _global_runtime = NeuralHookRuntime()
    return _global_runtime


# ==================== DECORATOR SYNTAX ====================

def neural_hook(
    module_name: str,
    function_name: str,
    hook_type: str = HookType.AFTER,
    priority: int = 50,
    condition: Optional[str] = None
):
    """
    Decorator for easy hook installation
    
    Usage:
        @neural_hook('myapp.core', 'process_data', hook_type='BEFORE')
        def my_debug_hook(original_fn, *args, **kwargs):
            print(f"Called with: {args}")
    """
    def decorator(func):
        runtime = get_global_runtime()
        
        hook_point = HookPoint(
            module_name=module_name,
            function_name=function_name,
            hook_type=hook_type,
            priority=priority,
            condition=condition
        )
        
        # Get function source
        hook_code = inspect.getsource(func)
        
        hook = NeuralHook(
            id=f"decorator_{func.__name__}",
            hook_point=hook_point,
            code=hook_code,
            metadata={'decorator': True, 'func_name': func.__name__}
        )
        
        runtime.install_hook(hook)
        
        return func
    
    return decorator


if __name__ == "__main__":
    # Example usage
    print("="*60)
    print("NEURAL HOOKS RUNTIME v2.0 - EXAMPLE")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Example: Debug hook
    debug_hook = """
print(f"🔍 Function called with {len(args)} args")
"""
    
    hook_id = runtime.install_hook_from_code(
        HookPoint(
            module_name="__main__",
            function_name="test_function",
            hook_type=HookType.BEFORE
        ),
        debug_hook,
        purpose="Debug logging"
    )
    
    if hook_id:
        print(f"\n✅ Installed hook: {hook_id}")
        print(f"\nStatistics: {runtime.get_statistics()}")
