#!/usr/bin/env python3
"""
Neural Hooks GUI Server - ACTUAL WORKING IMPLEMENTATION
=======================================================

This is a REAL web server that provides:
- REST API for hook management
- Real-time status updates
- SDCK analysis endpoint
- WebSocket for live updates

Usage:
    python gui_server.py

Then open http://localhost:5000 in your browser.
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Try to import Flask
try:
    from flask import Flask, jsonify, request, render_template_string
    from flask_cors import CORS
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False
    print("Flask not installed. Installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "flask-cors", "-q"])
    from flask import Flask, jsonify, request, render_template_string
    from flask_cors import CORS

from core import get_global_runtime, HookPoint, HookType, SDCKHookAnalyzer
from core.sdck_classifier import ForceClass

app = Flask(__name__)
CORS(app)

# HTML Template (the actual GUI)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neural Hooks v3.0 - Control Center</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-tertiary: #1a1a25;
            --accent-primary: #00d4ff;
            --accent-secondary: #ff006e;
            --accent-success: #00ff88;
            --accent-warning: #ffaa00;
            --accent-danger: #ff0044;
            --text-primary: #ffffff;
            --text-secondary: #a0a0b0;
            --border-color: #2a2a3a;
        }
        body {
            font-family: 'Segoe UI', Roboto, monospace;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
        }
        .header {
            padding: 20px 30px;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo { display: flex; align-items: center; gap: 15px; }
        .logo-icon {
            width: 50px; height: 50px;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 24px;
        }
        .logo-text h1 {
            font-size: 24px;
            background: linear-gradient(90deg, var(--accent-primary), var(--accent-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: calc(100vh - 91px);
        }
        .sidebar {
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 20px 0;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 15px 25px;
            cursor: pointer;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: var(--bg-tertiary);
            border-left-color: var(--accent-primary);
        }
        .main-content { padding: 30px; }
        .card {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 20px;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }
        .card-title {
            font-size: 14px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card-value {
            font-size: 36px;
            font-weight: bold;
            background: linear-gradient(90deg, var(--text-primary), var(--accent-primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
        }
        .btn-primary:hover { transform: translateY(-2px); }
        .btn-danger { background: var(--accent-danger); color: white; }
        .form-group { margin-bottom: 20px; }
        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-secondary);
            font-size: 14px;
        }
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 12px 16px;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 14px;
        }
        .form-textarea {
            min-height: 150px;
            font-family: monospace;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th, .data-table td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .data-table th {
            color: var(--text-secondary);
            font-size: 12px;
            text-transform: uppercase;
        }
        .badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-ally { background: rgba(0, 255, 136, 0.2); color: var(--accent-success); }
        .badge-enemy { background: rgba(255, 0, 68, 0.2); color: var(--accent-danger); }
        .badge-trojan { background: rgba(255, 170, 0, 0.2); color: var(--accent-warning); }
        .badge-parasite { background: rgba(255, 0, 110, 0.2); color: var(--accent-secondary); }
        .badge-inert { background: rgba(160, 160, 176, 0.2); color: var(--text-secondary); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .metric-card {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 24px;
            text-align: center;
        }
        .metric-value {
            font-size: 48px;
            font-weight: bold;
            color: var(--accent-primary);
        }
        .metric-label {
            color: var(--text-secondary);
            font-size: 14px;
            margin-top: 8px;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">
            <div class="logo-icon">⚡</div>
            <div class="logo-text">
                <h1>Neural Hooks</h1>
            </div>
        </div>
        <div style="color: var(--text-secondary);">v3.0 Production</div>
    </header>

    <div class="container">
        <nav class="sidebar">
            <div class="nav-item active" onclick="showTab('dashboard')">📊 Dashboard</div>
            <div class="nav-item" onclick="showTab('hooks')">🪝 Hooks</div>
            <div class="nav-item" onclick="showTab('install')">➕ Install</div>
            <div class="nav-item" onclick="showTab('analyze')">🧮 Analyze</div>
        </nav>

        <main class="main-content">
            <!-- Dashboard -->
            <div id="dashboard" class="tab-content active">
                <div class="dashboard-grid">
                    <div class="metric-card">
                        <div class="metric-value" id="metric-hooks">-</div>
                        <div class="metric-label">Active Hooks</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" id="metric-execs">-</div>
                        <div class="metric-label">Executions</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" id="metric-wrapped">-</div>
                        <div class="metric-label">Functions Wrapped</div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <span class="card-title">Force Class Distribution</span>
                    </div>
                    <div id="force-class-chart"></div>
                </div>
            </div>

            <!-- Hooks -->
            <div id="hooks" class="tab-content">
                <div class="card">
                    <div class="card-header">
                        <span class="card-title">Active Hooks</span>
                        <button class="btn btn-primary" onclick="refreshHooks()">🔄 Refresh</button>
                    </div>
                    <table class="data-table" id="hooks-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Module</th>
                                <th>Function</th>
                                <th>Type</th>
                                <th>Force Class</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>

            <!-- Install -->
            <div id="install" class="tab-content">
                <div class="card">
                    <h3 style="margin-bottom: 20px;">Install New Hook</h3>

                    <div class="form-group">
                        <label class="form-label">Target Module</label>
                        <input type="text" class="form-input" id="install-module" placeholder="e.g., myapp.core">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Target Function</label>
                        <input type="text" class="form-input" id="install-function" placeholder="e.g., process_data">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Hook Type</label>
                        <select class="form-select" id="install-type">
                            <option value="BEFORE">BEFORE</option>
                            <option value="AFTER">AFTER</option>
                            <option value="AROUND">AROUND</option>
                            <option value="MODIFY">MODIFY</option>
                            <option value="OBSERVE">OBSERVE</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Hook Code (Python)</label>
                        <textarea class="form-textarea" id="install-code" placeholder="# Enter your hook code here
print(f"Function called with {args}")"></textarea>
                    </div>

                    <button class="btn btn-primary" onclick="installHook()">Install Hook</button>

                    <div id="install-result" style="margin-top: 20px;"></div>
                </div>
            </div>

            <!-- Analyze -->
            <div id="analyze" class="tab-content">
                <div class="card">
                    <h3 style="margin-bottom: 20px;">SDCK Analysis</h3>

                    <div class="form-group">
                        <label class="form-label">Code to Analyze</label>
                        <textarea class="form-textarea" id="analyze-code" placeholder="# Paste code here to analyze"></textarea>
                    </div>

                    <button class="btn btn-primary" onclick="analyzeCode()">Analyze</button>

                    <div id="analyze-result" style="margin-top: 20px;"></div>
                </div>
            </div>
        </main>
    </div>

    <script>
        const API_BASE = '';

        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');

            if (tabName === 'dashboard') refreshDashboard();
            if (tabName === 'hooks') refreshHooks();
        }

        async function refreshDashboard() {
            const res = await fetch(`${API_BASE}/api/status`);
            const data = await res.json();

            document.getElementById('metric-hooks').textContent = data.active_hooks || 0;
            document.getElementById('metric-execs').textContent = data.executions || 0;
            document.getElementById('metric-wrapped').textContent = data.functions_wrapped || 0;

            // Force class chart
            const chart = document.getElementById('force-class-chart');
            chart.innerHTML = '';
            if (data.hooks_by_class) {
                for (const [fc, count] of Object.entries(data.hooks_by_class)) {
                    const div = document.createElement('div');
                    div.style.cssText = 'display:flex;align-items:center;margin:8px 0;';
                    div.innerHTML = `
                        <span style="width:100px;">${fc}</span>
                        <div style="flex:1;background:var(--bg-tertiary);height:24px;border-radius:4px;overflow:hidden;">
                            <div style="width:${count * 20}px;background:var(--accent-primary);height:100%;"></div>
                        </div>
                        <span style="width:50px;text-align:right;">${count}</span>
                    `;
                    chart.appendChild(div);
                }
            }
        }

        async function refreshHooks() {
            const res = await fetch(`${API_BASE}/api/hooks`);
            const hooks = await res.json();

            const tbody = document.querySelector('#hooks-table tbody');
            tbody.innerHTML = '';

            hooks.forEach(hook => {
                const tr = document.createElement('tr');
                const badgeClass = {
                    'ALLY': 'badge-ally',
                    'ENEMY': 'badge-enemy',
                    'TROJAN': 'badge-trojan',
                    'PARASITE': 'badge-parasite',
                    'INERT': 'badge-inert'
                }[hook.force_class] || 'badge-inert';

                tr.innerHTML = `
                    <td><code>${hook.id.substring(0, 8)}</code></td>
                    <td>${hook.module}</td>
                    <td>${hook.function}</td>
                    <td>${hook.type}</td>
                    <td><span class="badge ${badgeClass}">${hook.force_class}</span></td>
                    <td>
                        <button class="btn btn-danger" style="padding:6px 12px;font-size:12px;" 
                                onclick="removeHook('${hook.id}')">Remove</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        async function installHook() {
            const module = document.getElementById('install-module').value;
            const func = document.getElementById('install-function').value;
            const type = document.getElementById('install-type').value;
            const code = document.getElementById('install-code').value;

            const res = await fetch(`${API_BASE}/api/hooks`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({module, function: func, type, code})
            });

            const result = await res.json();
            const resultDiv = document.getElementById('install-result');

            if (result.success) {
                resultDiv.innerHTML = `<div style="color: var(--accent-success);">✅ Hook installed: ${result.hook_id}</div>`;
            } else {
                resultDiv.innerHTML = `<div style="color: var(--accent-danger);">❌ ${result.error}</div>`;
            }
        }

        async function removeHook(hookId) {
            if (!confirm('Remove this hook?')) return;

            const res = await fetch(`${API_BASE}/api/hooks/${hookId}`, {method: 'DELETE'});
            const result = await res.json();

            if (result.success) {
                refreshHooks();
            } else {
                alert('Failed to remove hook: ' + result.error);
            }
        }

        async function analyzeCode() {
            const code = document.getElementById('analyze-code').value;

            const res = await fetch(`${API_BASE}/api/analyze`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({code})
            });

            const result = await res.json();
            const resultDiv = document.getElementById('analyze-result');

            resultDiv.innerHTML = `
                <div class="card">
                    <h4>Analysis Results</h4>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin: 16px 0;">
                        <div style="text-align: center;">
                            <div style="font-size: 12px; color: var(--text-secondary);">g1 (Code Impact)</div>
                            <div style="font-size: 24px; color: var(--accent-primary);">${result.g1}</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 12px; color: var(--text-secondary);">g2 (Stability)</div>
                            <div style="font-size: 24px; color: var(--accent-primary);">${result.g2}</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 12px; color: var(--text-secondary);">g3 (Energy)</div>
                            <div style="font-size: 24px; color: var(--accent-primary);">${result.g3}</div>
                        </div>
                    </div>
                    <div style="margin-top: 16px;">
                        <div><strong>Force Class:</strong> ${result.force_class}</div>
                        <div><strong>Decision:</strong> ${result.decision}</div>
                        <div><strong>Risk Level:</strong> ${result.risk_level}</div>
                    </div>
                </div>
            `;
        }

        // Initial load
        refreshDashboard();
    </script>
</body>
</html>
"""


# ==================== API ROUTES ====================

@app.route('/')
def index():
    """Serve the main GUI"""
    return render_template_string(HTML_TEMPLATE)


@app.route('/api/status')
def api_status():
    """Get runtime status"""
    runtime = get_global_runtime()
    stats = runtime.get_statistics()
    return jsonify(stats)


@app.route('/api/hooks')
def api_list_hooks():
    """List all hooks"""
    runtime = get_global_runtime()
    hooks = runtime.list_hooks()

    return jsonify([{
        "id": hook.id,
        "module": hook.hook_point.module_name,
        "function": hook.hook_point.function_name,
        "type": hook.hook_point.hook_type,
        "force_class": hook.analysis.force_class.value,
        "decision": hook.analysis.decision.value,
    } for hook in hooks])


@app.route('/api/hooks', methods=['POST'])
def api_install_hook():
    """Install a new hook"""
    data = request.json

    module = data.get('module')
    function = data.get('function')
    hook_type_str = data.get('type', 'BEFORE')
    code = data.get('code')

    if not all([module, function, code]):
        return jsonify({"success": False, "error": "Missing required fields"})

    runtime = get_global_runtime()

    hook_point = HookPoint(
        module_name=module,
        function_name=function,
        hook_type=getattr(HookType, hook_type_str, HookType.BEFORE)
    )

    hook_id = runtime.install_hook_from_code(hook_point, code)

    if hook_id:
        return jsonify({"success": True, "hook_id": hook_id})
    else:
        return jsonify({"success": False, "error": "Installation failed"})


@app.route('/api/hooks/<hook_id>', methods=['DELETE'])
def api_remove_hook(hook_id):
    """Remove a hook"""
    runtime = get_global_runtime()

    # Find hook by partial ID
    hooks = runtime.list_hooks()
    matching = [h for h in hooks if h.id.startswith(hook_id)]

    if not matching:
        return jsonify({"success": False, "error": "Hook not found"})

    if runtime.uninstall_hook(matching[0].id):
        return jsonify({"success": True})
    else:
        return jsonify({"success": False, "error": "Removal failed"})


@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    """Analyze code with SDCK"""
    data = request.json
    code = data.get('code', '')

    analyzer = SDCKHookAnalyzer()
    analysis = analyzer.analyze_hook_code(code)

    return jsonify({
        "g1": round(analysis.g1_code_impact, 3),
        "g2": round(analysis.g2_stability, 3),
        "g3": round(analysis.g3_energy, 3),
        "force_class": analysis.force_class.value,
        "decision": analysis.decision.value,
        "risk_level": analysis.get_risk_level(),
        "safe_to_amplify": analysis.is_safe_to_amplify(),
    })


# ==================== MAIN ====================

if __name__ == '__main__':
    print("="*60)
    print("🚀 Neural Hooks GUI Server")
    print("="*60)
    print()
    print("Starting server on http://localhost:5000")
    print()
    print("Press Ctrl+C to stop")
    print("="*60)

    app.run(host='0.0.0.0', port=5000, debug=True)
