# ⚡ Neural Hooks v3.0

**Production Runtime Code Extension with SDCK Classification**

> "Latency is a feature, a bug is a failure"

---

## 🚀 QUICK START - ONE COMMAND

```bash
# Clone or download, then:
python neural_hooks.py
```

That's it. Everything else is automatic.

---

## 📦 Installation (Optional)

### Option 1: Automatic (Recommended)
```bash
./install.sh
```

### Option 2: Manual
```bash
pip install -r requirements.txt
```

### Option 3: pip install
```bash
pip install .
```

---

## 🎮 Usage

### Start GUI (Default)
```bash
python neural_hooks.py
```
Opens browser automatically at `http://localhost:5000`

### Interactive CLI Mode
```bash
python neural_hooks.py --cli
```

### Quick Status Check
```bash
python neural_hooks.py --status
```

### Run Demo
```bash
python neural_hooks.py --demo
```

### Custom Port
```bash
python neural_hooks.py --port 8080
```

---

## 📁 Project Structure

```
neural_hooks_audit/
├── neural_hooks.py          # ⭐ UNIFIED LAUNCHER - Start here!
├── install.sh               # Quick install script
├── requirements.txt         # Python dependencies
├── setup.py                 # pip install support
│
├── core/                    # Core runtime
│   ├── __init__.py
│   ├── sdck_classifier.py       # Original SDCK
│   ├── sdck_classifier_v3.py    # Inverted SDCK + Master Profile
│   ├── runtime.py               # Original runtime
│   ├── runtime_v2_1.py          # Enhanced runtime
│   └── runtime_v3.py            # Production runtime (all fixes)
│
├── security/                # AST security
│   ├── __init__.py
│   └── ast_transformer.py
│
├── performance/             # JIT optimization
│   ├── __init__.py
│   └── optimizer.py
│
├── distributed/             # Gossip protocol
│   ├── __init__.py
│   ├── node_manager.py
│   └── conflict_resolver.py
│
├── ai/                      # Hook generation
│   ├── __init__.py
│   └── hook_generator.py
│
├── tools/                   # CLI tools
│   └── nhooks_cli.py
│
├── gui/                     # Web interface
│   ├── gui_server.py        # Flask server with REST API
│   └── index.html           # Static HTML (fallback)
│
├── examples/                # Example code
│   └── comprehensive_examples.py
│
└── docs/                    # Documentation
    ├── README.md
    ├── AUDIT_REPORT.md
    └── WHAT_WAS_ACTUALLY_DONE.md
```

---

## 🧮 SDCK Classification

The **SDCK (Signal-Decay-Code-Kinetic) Force Classifier** analyzes hooks using 3 gradients:

| Gradient | Measures | Range |
|----------|----------|-------|
| **g1** | Code Impact | -1 (destructive) to +1 (beneficial) |
| **g2** | Stability | -1 (fragile) to +1 (robust) |
| **g3** | Energy Efficiency | -1 (drain) to +1 (gain) |

### Force Classes

| Class | Description | Decision |
|-------|-------------|----------|
| **ALLY** | Full benefit | AMPLIFY |
| **BENEFACTOR** | Local benefit | ALLOW |
| **INERT** | No effect | IGNORE |
| **PARASITE** | Energy drain | ISOLATE |
| **TROJAN** | Delayed harm | ISOLATE |
| **ENEMY** | Destructive | NEUTRALIZE |

---

## 👑 Master Developer Profile

For development/testing, use the master profile to bypass all restrictions:

```python
from core.sdck_classifier_v3 import MASTER_DEV_PROFILE

# Master profile has:
# - bypass_sdck: Skip classification
# - bypass_security: Skip validation
# - bypass_timeout: No execution limits
# - bypass_quota: Unlimited hooks
# - use_inverted_sdck: Chaos mode
```

---

## 🔒 Security Features

- ✅ AST-based code transformation (no eval/exec)
- ✅ Hook execution timeout (5s default)
- ✅ Full SHA-256 for hook IDs
- ✅ Security policy enforcement
- ✅ Bytecode analysis
- ✅ Forbidden operation detection

---

## ⚡ Performance Features

- ✅ JIT compilation cache
- ✅ Lazy hook evaluation
- ✅ Hot path detection
- ✅ Performance profiling
- ✅ Bounded memory usage

---

## 🌐 Distributed Features

- ✅ Gossip-based node discovery
- ✅ Vector clock causality tracking
- ✅ SDCK conflict resolution
- ✅ Hook versioning and merging

---

## 🛠️ CLI Commands

```bash
# Initialize project
python tools/nhooks_cli.py init myproject

# Generate hook from description
python tools/nhooks_cli.py generate "Log function calls" --output hook.py

# Install hook
python tools/nhooks_cli.py install hook.py mymodule myfunction

# List hooks
python tools/nhooks_cli.py list

# Remove hook
python tools/nhooks_cli.py remove <hook_id>

# Show status
python tools/nhooks_cli.py status

# Analyze code
python tools/nhooks_cli.py analyze --code "print('hello')"
```

---

## 🧪 Python API

```python
from core import get_global_runtime, HookPoint, HookType

# Get runtime
runtime = get_global_runtime()

# Install a hook
hook_id = runtime.install_hook_from_code(
    hook_point=HookPoint("mymodule", "myfunc", HookType.BEFORE),
    code="print(f'Hooked: {args}')"
)

# List hooks
for hook in runtime.list_hooks():
    print(f"{hook.id}: {hook.analysis.force_class.value}")

# Get statistics
stats = runtime.get_statistics()
print(f"Active hooks: {stats['active_hooks']}")

# Remove hook
runtime.uninstall_hook(hook_id)
```

---

## 📊 Statistics

- **Total Files**: 35
- **Lines of Code**: ~17,000
- **Python Modules**: 28
- **Test Coverage**: All core functions verified

---

## 📝 License

MIT License - See LICENSE file

---

## 🙏 Acknowledgments

- SDCK Force Classifier inspired by signal processing theory
- Gossip protocol based on academic research
- JIT optimization inspired by modern JavaScript engines

---

**Version**: 3.0.0  
**Author**: Neural Hooks Production System  
**Status**: Production Ready ✅
