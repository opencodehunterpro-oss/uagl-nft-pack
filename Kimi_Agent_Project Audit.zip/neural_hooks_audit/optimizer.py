"""
HOOK PERFORMANCE OPTIMIZER
==========================

JIT compilation cache and performance optimization for hooks.

Key Features:
- Bytecode caching (compile once, execute many times)
- Lazy hook evaluation (skip disabled hooks)
- Hot path detection (optimize frequently-called hooks)
- Performance profiling

Author: Samet (SATEN)
Version: 2.0
Phase: 2 (Performance Optimization)
"""

import time
import hashlib
import pickle
from typing import Dict, List, Callable, Any, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import threading
from functools import lru_cache, wraps


# ==================== PERFORMANCE METRICS ====================

@dataclass
class HookPerformanceMetrics:
    """Performance metrics for a single hook"""
    hook_id: str
    
    # Execution counts
    total_executions: int = 0
    successful_executions: int = 0
    failed_executions: int = 0
    
    # Timing (in seconds)
    total_time: float = 0.0
    min_time: float = float('inf')
    max_time: float = 0.0
    
    # Compilation
    compilation_time: float = 0.0
    compiled_at: float = 0.0
    
    # Cache
    cache_hits: int = 0
    cache_misses: int = 0
    
    def record_execution(self, duration: float, success: bool = True):
        """Record an execution"""
        self.total_executions += 1
        if success:
            self.successful_executions += 1
        else:
            self.failed_executions += 1
        
        self.total_time += duration
        self.min_time = min(self.min_time, duration)
        self.max_time = max(self.max_time, duration)
    
    @property
    def average_time(self) -> float:
        """Average execution time"""
        if self.total_executions == 0:
            return 0.0
        return self.total_time / self.total_executions
    
    @property
    def success_rate(self) -> float:
        """Success rate percentage"""
        if self.total_executions == 0:
            return 0.0
        return (self.successful_executions / self.total_executions) * 100
    
    @property
    def cache_hit_rate(self) -> float:
        """Cache hit rate percentage"""
        total_cache_ops = self.cache_hits + self.cache_misses
        if total_cache_ops == 0:
            return 0.0
        return (self.cache_hits / total_cache_ops) * 100
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'hook_id': self.hook_id,
            'executions': {
                'total': self.total_executions,
                'successful': self.successful_executions,
                'failed': self.failed_executions,
                'success_rate': f"{self.success_rate:.2f}%"
            },
            'timing': {
                'total': f"{self.total_time:.6f}s",
                'average': f"{self.average_time:.6f}s",
                'min': f"{self.min_time:.6f}s",
                'max': f"{self.max_time:.6f}s"
            },
            'compilation': {
                'time': f"{self.compilation_time:.6f}s",
                'compiled_at': self.compiled_at
            },
            'cache': {
                'hits': self.cache_hits,
                'misses': self.cache_misses,
                'hit_rate': f"{self.cache_hit_rate:.2f}%"
            }
        }


# ==================== JIT COMPILATION CACHE ====================

class JITCompilationCache:
    """
    Just-In-Time compilation cache
    
    Compiles hook code once and caches the result.
    Significantly improves performance for frequently-executed hooks.
    """
    
    def __init__(self, max_size: int = 1000):
        """
        Initialize JIT cache
        
        Args:
            max_size: Maximum number of cached compilations
        """
        self.max_size = max_size
        self.cache: Dict[str, Tuple[Callable, float]] = {}  # code_hash -> (compiled_func, compile_time)
        self.lock = threading.RLock()
        
        # Statistics
        self.hits = 0
        self.misses = 0
        self.evictions = 0
    
    def get_code_hash(self, code: str) -> str:
        """
        Get hash of code for cache key
        
        Args:
            code: Python code string
        
        Returns:
            SHA-256 hash
        """
        return hashlib.sha256(code.encode()).hexdigest()[:16]
    
    def get(self, code: str) -> Optional[Tuple[Callable, float]]:
        """
        Get compiled function from cache
        
        Args:
            code: Python code string
        
        Returns:
            (compiled_function, compile_time) if cached, None otherwise
        """
        code_hash = self.get_code_hash(code)
        
        with self.lock:
            if code_hash in self.cache:
                self.hits += 1
                return self.cache[code_hash]
            else:
                self.misses += 1
                return None
    
    def put(self, code: str, compiled_func: Callable, compile_time: float) -> None:
        """
        Store compiled function in cache
        
        Args:
            code: Python code string
            compiled_func: Compiled function
            compile_time: Time taken to compile
        """
        code_hash = self.get_code_hash(code)
        
        with self.lock:
            # Evict oldest if cache full
            if len(self.cache) >= self.max_size:
                # Simple FIFO eviction (could use LRU)
                oldest_key = next(iter(self.cache))
                del self.cache[oldest_key]
                self.evictions += 1
            
            self.cache[code_hash] = (compiled_func, compile_time)
    
    def clear(self) -> None:
        """Clear cache"""
        with self.lock:
            self.cache.clear()
            self.hits = 0
            self.misses = 0
            self.evictions = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        with self.lock:
            total_ops = self.hits + self.misses
            hit_rate = (self.hits / total_ops * 100) if total_ops > 0 else 0.0
            
            return {
                'size': len(self.cache),
                'max_size': self.max_size,
                'hits': self.hits,
                'misses': self.misses,
                'evictions': self.evictions,
                'hit_rate': f"{hit_rate:.2f}%"
            }


# ==================== LAZY HOOK EVALUATOR ====================

class LazyHookEvaluator:
    """
    Lazy evaluation for hooks
    
    Skips hooks that are:
    - Disabled
    - Conditionally inactive
    - Low priority and execution budget exceeded
    """
    
    def __init__(self):
        self.disabled_hooks: set[str] = set()
        self.execution_budget: Dict[str, int] = {}  # hook_id -> remaining executions
        self.lock = threading.RLock()
    
    def disable_hook(self, hook_id: str) -> None:
        """Disable a hook (will be skipped)"""
        with self.lock:
            self.disabled_hooks.add(hook_id)
    
    def enable_hook(self, hook_id: str) -> None:
        """Enable a hook"""
        with self.lock:
            self.disabled_hooks.discard(hook_id)
    
    def is_enabled(self, hook_id: str) -> bool:
        """Check if hook is enabled"""
        with self.lock:
            return hook_id not in self.disabled_hooks
    
    def set_execution_budget(self, hook_id: str, budget: int) -> None:
        """
        Set execution budget for a hook
        
        Args:
            hook_id: Hook identifier
            budget: Maximum number of executions allowed
        """
        with self.lock:
            self.execution_budget[hook_id] = budget
    
    def can_execute(self, hook_id: str) -> bool:
        """
        Check if hook can execute (not disabled, has budget)
        
        Args:
            hook_id: Hook identifier
        
        Returns:
            True if hook can execute
        """
        with self.lock:
            # Check disabled
            if hook_id in self.disabled_hooks:
                return False
            
            # Check budget
            if hook_id in self.execution_budget:
                if self.execution_budget[hook_id] <= 0:
                    return False
                self.execution_budget[hook_id] -= 1
            
            return True


# ==================== HOT PATH DETECTOR ====================

class HotPathDetector:
    """
    Detect frequently-executed hooks (hot paths)
    
    Hot paths can be optimized differently than cold paths.
    """
    
    def __init__(self, hot_threshold: int = 100):
        """
        Initialize detector
        
        Args:
            hot_threshold: Number of executions to consider "hot"
        """
        self.hot_threshold = hot_threshold
        self.execution_counts: Dict[str, int] = defaultdict(int)
        self.lock = threading.RLock()
    
    def record_execution(self, hook_id: str) -> None:
        """Record an execution"""
        with self.lock:
            self.execution_counts[hook_id] += 1
    
    def is_hot(self, hook_id: str) -> bool:
        """Check if hook is on hot path"""
        with self.lock:
            return self.execution_counts[hook_id] >= self.hot_threshold
    
    def get_hot_hooks(self) -> List[Tuple[str, int]]:
        """Get list of hot hooks sorted by execution count"""
        with self.lock:
            return sorted(
                [(hook_id, count) for hook_id, count in self.execution_counts.items()
                 if count >= self.hot_threshold],
                key=lambda x: x[1],
                reverse=True
            )
    
    def reset(self) -> None:
        """Reset all counters"""
        with self.lock:
            self.execution_counts.clear()


# ==================== PERFORMANCE OPTIMIZER ====================

class HookPerformanceOptimizer:
    """
    Main performance optimization system
    
    Combines:
    - JIT compilation cache
    - Lazy evaluation
    - Hot path detection
    - Performance profiling
    """
    
    def __init__(self, 
                 cache_size: int = 1000,
                 hot_threshold: int = 100,
                 enable_profiling: bool = True):
        """
        Initialize optimizer
        
        Args:
            cache_size: Size of JIT cache
            hot_threshold: Executions needed for "hot" classification
            enable_profiling: Enable detailed profiling
        """
        self.jit_cache = JITCompilationCache(max_size=cache_size)
        self.lazy_evaluator = LazyHookEvaluator()
        self.hot_path_detector = HotPathDetector(hot_threshold=hot_threshold)
        
        self.enable_profiling = enable_profiling
        self.metrics: Dict[str, HookPerformanceMetrics] = {}
        self.lock = threading.RLock()
    
    def compile_with_cache(self, 
                          hook_id: str,
                          code: str,
                          compiler: Callable[[str, str], Callable]) -> Callable:
        """
        Compile hook with JIT caching
        
        Args:
            hook_id: Hook identifier
            code: Python code
            compiler: Compilation function
        
        Returns:
            Compiled function
        """
        # Try cache first
        cached = self.jit_cache.get(code)
        if cached:
            compiled_func, compile_time = cached
            if self.enable_profiling:
                self._get_metrics(hook_id).cache_hits += 1
                self._get_metrics(hook_id).compilation_time = compile_time
            return compiled_func
        
        # Cache miss - compile
        if self.enable_profiling:
            self._get_metrics(hook_id).cache_misses += 1
        
        start_time = time.perf_counter()
        compiled_func = compiler(code, hook_id)
        compile_time = time.perf_counter() - start_time
        
        # Store in cache
        self.jit_cache.put(code, compiled_func, compile_time)
        
        if self.enable_profiling:
            self._get_metrics(hook_id).compilation_time = compile_time
            self._get_metrics(hook_id).compiled_at = time.time()
        
        return compiled_func
    
    def should_execute(self, hook_id: str) -> bool:
        """
        Check if hook should execute (lazy evaluation)
        
        Args:
            hook_id: Hook identifier
        
        Returns:
            True if hook should execute
        """
        return self.lazy_evaluator.can_execute(hook_id)
    
    def record_execution(self, hook_id: str, duration: float, success: bool = True) -> None:
        """
        Record hook execution
        
        Args:
            hook_id: Hook identifier
            duration: Execution time in seconds
            success: Whether execution succeeded
        """
        # Hot path detection
        self.hot_path_detector.record_execution(hook_id)
        
        # Profiling
        if self.enable_profiling:
            self._get_metrics(hook_id).record_execution(duration, success)
    
    def wrap_for_profiling(self, hook_id: str, func: Callable) -> Callable:
        """
        Wrap function with profiling instrumentation
        
        Args:
            hook_id: Hook identifier
            func: Function to wrap
        
        Returns:
            Wrapped function
        """
        if not self.enable_profiling:
            return func
        
        @wraps(func)
        def profiled_wrapper(*args, **kwargs):
            # Check lazy evaluation
            if not self.should_execute(hook_id):
                return None
            
            # Profile execution
            start_time = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                duration = time.perf_counter() - start_time
                self.record_execution(hook_id, duration, success=True)
                return result
            except Exception as e:
                duration = time.perf_counter() - start_time
                self.record_execution(hook_id, duration, success=False)
                raise
        
        return profiled_wrapper
    
    def _get_metrics(self, hook_id: str) -> HookPerformanceMetrics:
        """Get or create metrics for hook"""
        with self.lock:
            if hook_id not in self.metrics:
                self.metrics[hook_id] = HookPerformanceMetrics(hook_id=hook_id)
            return self.metrics[hook_id]
    
    def get_report(self) -> Dict[str, Any]:
        """Get comprehensive performance report"""
        with self.lock:
            # Overall stats
            total_executions = sum(m.total_executions for m in self.metrics.values())
            total_time = sum(m.total_time for m in self.metrics.values())
            
            # Top hooks by execution count
            top_by_count = sorted(
                self.metrics.items(),
                key=lambda x: x[1].total_executions,
                reverse=True
            )[:10]
            
            # Top hooks by total time
            top_by_time = sorted(
                self.metrics.items(),
                key=lambda x: x[1].total_time,
                reverse=True
            )[:10]
            
            # Hot paths
            hot_hooks = self.hot_path_detector.get_hot_hooks()
            
            return {
                'summary': {
                    'total_hooks': len(self.metrics),
                    'total_executions': total_executions,
                    'total_time': f"{total_time:.6f}s",
                    'average_time_per_hook': f"{(total_time / total_executions if total_executions > 0 else 0):.6f}s"
                },
                'jit_cache': self.jit_cache.get_stats(),
                'top_hooks_by_count': [
                    {'hook_id': hook_id, 'count': metrics.total_executions}
                    for hook_id, metrics in top_by_count
                ],
                'top_hooks_by_time': [
                    {'hook_id': hook_id, 'time': f"{metrics.total_time:.6f}s"}
                    for hook_id, metrics in top_by_time
                ],
                'hot_paths': [
                    {'hook_id': hook_id, 'executions': count}
                    for hook_id, count in hot_hooks
                ],
                'individual_metrics': {
                    hook_id: metrics.to_dict()
                    for hook_id, metrics in self.metrics.items()
                }
            }
    
    def reset(self) -> None:
        """Reset all performance data"""
        with self.lock:
            self.jit_cache.clear()
            self.hot_path_detector.reset()
            self.metrics.clear()


# ==================== USAGE EXAMPLE ====================

if __name__ == "__main__":
    import json
    
    print("="*60)
    print("HOOK PERFORMANCE OPTIMIZER - DEMO")
    print("="*60)
    
    # Create optimizer
    optimizer = HookPerformanceOptimizer(
        cache_size=100,
        hot_threshold=10,
        enable_profiling=True
    )
    
    # Simulate hook compilation and execution
    def dummy_compiler(code: str, hook_id: str) -> Callable:
        """Dummy compiler for testing"""
        time.sleep(0.001)  # Simulate compilation time
        return lambda *args, **kwargs: len(code)
    
    # Test 1: JIT Cache
    print("\n🧪 Test 1: JIT Compilation Cache")
    
    code1 = "print('hello')"
    
    # First compile (cache miss)
    start = time.perf_counter()
    func1 = optimizer.compile_with_cache("hook1", code1, dummy_compiler)
    time1 = time.perf_counter() - start
    print(f"   First compile: {time1*1000:.3f}ms (cache miss)")
    
    # Second compile (cache hit)
    start = time.perf_counter()
    func2 = optimizer.compile_with_cache("hook1", code1, dummy_compiler)
    time2 = time.perf_counter() - start
    print(f"   Second compile: {time2*1000:.3f}ms (cache hit)")
    print(f"   Speedup: {time1/time2:.1f}x faster!")
    
    # Test 2: Hot Path Detection
    print("\n🧪 Test 2: Hot Path Detection")
    
    # Execute hook multiple times
    for i in range(50):
        optimizer.record_execution("hot_hook", 0.001)
    
    hot_hooks = optimizer.hot_path_detector.get_hot_hooks()
    print(f"   Hot hooks detected: {len(hot_hooks)}")
    if hot_hooks:
        print(f"   Hottest: {hot_hooks[0][0]} ({hot_hooks[0][1]} executions)")
    
    # Test 3: Lazy Evaluation
    print("\n🧪 Test 3: Lazy Evaluation")
    
    # Set execution budget
    optimizer.lazy_evaluator.set_execution_budget("limited_hook", 5)
    
    executions = 0
    for i in range(10):
        if optimizer.should_execute("limited_hook"):
            executions += 1
    
    print(f"   Budget: 5, Actual executions: {executions}")
    
    # Disable hook
    optimizer.lazy_evaluator.disable_hook("disabled_hook")
    can_exec = optimizer.should_execute("disabled_hook")
    print(f"   Disabled hook can execute: {can_exec}")
    
    # Test 4: Performance Report
    print("\n🧪 Test 4: Performance Report")
    
    # Simulate various executions
    for i in range(100):
        optimizer.record_execution("freq_hook", 0.0001, success=True)
    
    for i in range(10):
        optimizer.record_execution("slow_hook", 0.01, success=True)
    
    report = optimizer.get_report()
    
    print(f"\n📊 Summary:")
    print(f"   Total hooks: {report['summary']['total_hooks']}")
    print(f"   Total executions: {report['summary']['total_executions']}")
    print(f"   Total time: {report['summary']['total_time']}")
    
    print(f"\n💾 JIT Cache:")
    print(f"   Hit rate: {report['jit_cache']['hit_rate']}")
    print(f"   Size: {report['jit_cache']['size']}/{report['jit_cache']['max_size']}")
    
    print(f"\n🔥 Top Hooks by Count:")
    for hook in report['top_hooks_by_count'][:3]:
        print(f"   - {hook['hook_id']}: {hook['count']} executions")
    
    print("\n" + "="*60)
    print("✅ PERFORMANCE OPTIMIZATION WORKING!")
    print("="*60)
