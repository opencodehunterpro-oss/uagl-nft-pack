# ⚡ Neural Hooks v3.0 - QUICKSTART

## 30-Second Start

```bash
python neural_hooks.py
```

Done. Browser opens automatically.

---

## What Just Happened?

1. ✅ Checked Python version (3.8+)
2. ✅ Installed dependencies (Flask, flask-cors)
3. ✅ Configured environment (~/.neural_hooks/)
4. ✅ Initialized runtime
5. ✅ Started GUI server on port 5000
6. ✅ Opened browser

---

## Common Commands

| Command | What It Does |
|---------|--------------|
| `python neural_hooks.py` | Start GUI (default) |
| `python neural_hooks.py --cli` | Interactive terminal |
| `python neural_hooks.py --status` | Quick stats |
| `python neural_hooks.py --demo` | Run demo |
| `python neural_hooks.py --port 8080` | Use port 8080 |

---

## First Hook (Interactive CLI)

```bash
$ python neural_hooks.py --cli

nhooks> demo
# Runs demo with test hooks

nhooks> status
# Shows runtime stats

nhooks> list
# Lists active hooks

nhooks> exit
```

---

## First Hook (Python)

```python
from core import get_global_runtime, HookPoint, HookType

runtime = get_global_runtime()

# Install hook
hook_id = runtime.install_hook_from_code(
    HookPoint("mymodule", "myfunc", HookType.BEFORE),
    "print(f'Called with: {args}')"
)

print(f"Hook installed: {hook_id}")
```

---

## Troubleshooting

### Port 5000 in use?
```bash
python neural_hooks.py --port 8080
```

### Dependencies missing?
```bash
pip install -r requirements.txt
```

### Permission denied?
```bash
chmod +x neural_hooks.py install.sh
```

---

## Next Steps

- Read `docs/AUDIT_REPORT.md` for technical details
- Read `docs/WHAT_WAS_ACTUALLY_DONE.md` for implementation notes
- Explore the GUI at http://localhost:5000
- Try `python neural_hooks.py --demo`

---

**That's it! You're ready to use Neural Hooks.** ⚡
