"""
SDCK-BASED CONFLICT RESOLUTION
===============================

Distributed conflict resolution using SDCK force classification.

When multiple nodes have different versions of the same hook,
we use SDCK analysis to determine which version is "better".

Features:
- SDCK force comparison
- Vector clocks for causality
- CRDT-style merging
- Deterministic resolution

Author: Samet (SATEN)
Version: 2.0
Phase: 3 (Distributed System)
"""

import time
import hashlib
import json
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum
import logging

# Import SDCK
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.sdck_classifier import (
    ForceClass, DecisionCode, classify_force, map_decision
)

logger = logging.getLogger(__name__)


# ==================== VECTOR CLOCK ====================

@dataclass
class VectorClock:
    """
    Vector clock for tracking causality in distributed system
    
    Each node maintains a counter. When an event occurs:
    - Increment own counter
    - Merge with received vector clocks
    
    This allows us to determine:
    - Concurrent events (conflict)
    - Causally ordered events (no conflict)
    """
    clocks: Dict[str, int] = field(default_factory=dict)
    
    def increment(self, node_id: str) -> None:
        """Increment counter for a node"""
        self.clocks[node_id] = self.clocks.get(node_id, 0) + 1
    
    def merge(self, other: 'VectorClock') -> None:
        """Merge with another vector clock (take max of each counter)"""
        for node_id, count in other.clocks.items():
            self.clocks[node_id] = max(self.clocks.get(node_id, 0), count)
    
    def happens_before(self, other: 'VectorClock') -> bool:
        """
        Check if this clock happens before other (causality)
        
        this <= other if:
        - For all nodes, this[node] <= other[node]
        - For at least one node, this[node] < other[node]
        """
        all_less_or_equal = True
        at_least_one_less = False
        
        all_nodes = set(self.clocks.keys()) | set(other.clocks.keys())
        
        for node_id in all_nodes:
            this_count = self.clocks.get(node_id, 0)
            other_count = other.clocks.get(node_id, 0)
            
            if this_count > other_count:
                all_less_or_equal = False
                break
            
            if this_count < other_count:
                at_least_one_less = True
        
        return all_less_or_equal and at_least_one_less
    
    def concurrent_with(self, other: 'VectorClock') -> bool:
        """
        Check if this clock is concurrent with other (conflict!)
        
        Concurrent if neither happens before the other
        """
        return not self.happens_before(other) and not other.happens_before(self)
    
    def to_dict(self) -> Dict[str, int]:
        """Convert to dictionary"""
        return self.clocks.copy()
    
    @classmethod
    def from_dict(cls, data: Dict[str, int]) -> 'VectorClock':
        """Create from dictionary"""
        return cls(clocks=data.copy())
    
    def __repr__(self) -> str:
        return f"VectorClock({self.clocks})"


# ==================== HOOK VERSION ====================

@dataclass
class HookVersion:
    """
    Versioned hook with vector clock and SDCK analysis
    """
    # Identity
    hook_id: str
    node_id: str  # Node that created this version
    
    # Content
    code: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Versioning
    vector_clock: VectorClock = field(default_factory=VectorClock)
    version_hash: str = ""
    
    # SDCK Analysis
    g1_code_impact: float = 0.0
    g2_stability: float = 0.0
    g3_energy: float = 0.0
    force_class: str = ForceClass.INERT.value
    decision: str = DecisionCode.IGNORE.value
    
    # Timing
    created_at: float = field(default_factory=time.time)
    modified_at: float = field(default_factory=time.time)
    
    def __post_init__(self):
        """Compute version hash"""
        if not self.version_hash:
            self.version_hash = self._compute_hash()
    
    def _compute_hash(self) -> str:
        """Compute content hash for version"""
        content = f"{self.hook_id}{self.code}{self.force_class}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            **asdict(self),
            'vector_clock': self.vector_clock.to_dict()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'HookVersion':
        """Create from dictionary"""
        data = data.copy()
        data['vector_clock'] = VectorClock.from_dict(data['vector_clock'])
        return cls(**data)


# ==================== CONFLICT RESOLUTION STRATEGY ====================

class ConflictResolutionStrategy(str, Enum):
    """Strategy for resolving conflicts"""
    SDCK_FORCE = "SDCK_FORCE"          # Use SDCK force classification
    LAST_WRITE_WINS = "LAST_WRITE_WINS"  # Use timestamp
    MANUAL = "MANUAL"                  # Require manual resolution
    MERGE = "MERGE"                    # Attempt automatic merge


# ==================== CONFLICT ====================

@dataclass
class Conflict:
    """
    Represents a conflict between hook versions
    """
    hook_id: str
    versions: List[HookVersion]
    detected_at: float = field(default_factory=time.time)
    resolved: bool = False
    resolution_strategy: Optional[ConflictResolutionStrategy] = None
    winner: Optional[HookVersion] = None
    
    def is_concurrent(self) -> bool:
        """Check if versions are concurrent (true conflict)"""
        if len(self.versions) < 2:
            return False
        
        # Check all pairs
        for i in range(len(self.versions)):
            for j in range(i + 1, len(self.versions)):
                v1, v2 = self.versions[i], self.versions[j]
                if v1.vector_clock.concurrent_with(v2.vector_clock):
                    return True
        
        return False


# ==================== SDCK-BASED CONFLICT RESOLVER ====================

class SDCKConflictResolver:
    """
    Resolve conflicts using SDCK force classification
    
    When multiple versions exist, we compare their SDCK classifications
    and choose the "best" one according to a priority hierarchy.
    
    Priority (highest to lowest):
    1. ALLY (g1>0, g2>=0, g3>=0) - Best overall
    2. BENEFACTOR (g1>0, g2>=0, g3>=0, !global) - Good but local only
    3. INERT (g1=0) - No harm
    4. PARASITE (g1>0, g2>=0, g3<0) - Benefit but energy drain
    5. TROJAN (g1>0, g2<0) - Benefit but unstable
    6. ENEMY (g1<0) - Destructive
    """
    
    # Force class priority (higher = better)
    FORCE_PRIORITY = {
        ForceClass.ALLY: 6,
        ForceClass.BENEFACTOR: 5,
        ForceClass.INERT: 4,
        ForceClass.PARASITE: 3,
        ForceClass.TROJAN: 2,
        ForceClass.ENEMY: 1
    }
    
    def __init__(self):
        logger.info("🔀 SDCK Conflict Resolver initialized")
    
    def resolve(self, conflict: Conflict) -> Optional[HookVersion]:
        """
        Resolve conflict using SDCK classification
        
        Args:
            conflict: Conflict to resolve
        
        Returns:
            Winning version or None if cannot resolve
        """
        if not conflict.versions:
            return None
        
        if len(conflict.versions) == 1:
            return conflict.versions[0]
        
        # Sort versions by SDCK priority
        sorted_versions = sorted(
            conflict.versions,
            key=lambda v: self._version_score(v),
            reverse=True
        )
        
        winner = sorted_versions[0]
        
        logger.info(
            f"🔀 Conflict resolved for {conflict.hook_id}: "
            f"Winner = {winner.node_id} ({winner.force_class})"
        )
        
        conflict.resolved = True
        conflict.resolution_strategy = ConflictResolutionStrategy.SDCK_FORCE
        conflict.winner = winner
        
        return winner
    
    def _version_score(self, version: HookVersion) -> float:
        """
        Calculate score for a version
        
        Score components:
        1. Force class priority (primary)
        2. Gradient values (tie-breaker)
        3. Timestamp (final tie-breaker)
        
        Returns:
            Score (higher = better)
        """
        force_class = ForceClass(version.force_class)
        
        # Primary: Force class priority
        priority_score = self.FORCE_PRIORITY.get(force_class, 0) * 1000
        
        # Secondary: Gradient values
        # Prefer higher g1 (code impact), g2 (stability), g3 (energy)
        gradient_score = (
            version.g1_code_impact * 100 +
            version.g2_stability * 10 +
            version.g3_energy * 1
        )
        
        # Tertiary: Timestamp (newer is slightly better)
        time_score = version.modified_at / 1e10  # Normalize to small value
        
        return priority_score + gradient_score + time_score
    
    def compare_versions(self, v1: HookVersion, v2: HookVersion) -> int:
        """
        Compare two versions
        
        Returns:
            1 if v1 is better, -1 if v2 is better, 0 if equal
        """
        score1 = self._version_score(v1)
        score2 = self._version_score(v2)
        
        if score1 > score2:
            return 1
        elif score1 < score2:
            return -1
        else:
            return 0


# ==================== CRDT-STYLE MERGE ====================

class HookMerger:
    """
    CRDT-style merging of hook versions
    
    Attempt to merge two versions by combining their best aspects.
    This is an optimistic merge - not always possible.
    """
    
    def can_merge(self, v1: HookVersion, v2: HookVersion) -> bool:
        """
        Check if two versions can be merged
        
        Mergeable if:
        - Same force class
        - Similar gradients
        - Compatible code
        """
        # Same force class
        if v1.force_class != v2.force_class:
            return False
        
        # Similar gradients (within 0.3)
        if abs(v1.g1_code_impact - v2.g1_code_impact) > 0.3:
            return False
        if abs(v1.g2_stability - v2.g2_stability) > 0.3:
            return False
        if abs(v1.g3_energy - v2.g3_energy) > 0.3:
            return False
        
        return True
    
    def merge(self, v1: HookVersion, v2: HookVersion) -> Optional[HookVersion]:
        """
        Merge two versions
        
        Args:
            v1, v2: Versions to merge
        
        Returns:
            Merged version or None if cannot merge
        """
        if not self.can_merge(v1, v2):
            logger.warning(f"⚠️ Cannot merge {v1.hook_id} versions (incompatible)")
            return None
        
        # Create merged version
        merged = HookVersion(
            hook_id=v1.hook_id,
            node_id=f"{v1.node_id}+{v2.node_id}",  # Composite
            code=self._merge_code(v1.code, v2.code),
            metadata={**v1.metadata, **v2.metadata},
            vector_clock=self._merge_vector_clocks(v1.vector_clock, v2.vector_clock),
            g1_code_impact=max(v1.g1_code_impact, v2.g1_code_impact),
            g2_stability=max(v1.g2_stability, v2.g2_stability),
            g3_energy=max(v1.g3_energy, v2.g3_energy),
            force_class=v1.force_class,  # Same force class
            decision=v1.decision,
            created_at=min(v1.created_at, v2.created_at),
            modified_at=max(v1.modified_at, v2.modified_at)
        )
        
        logger.info(f"🔀 Merged {v1.hook_id} from {v1.node_id} and {v2.node_id}")
        
        return merged
    
    def _merge_code(self, code1: str, code2: str) -> str:
        """
        Merge code (simplistic - just take longer version)
        
        In practice, this would use AST merging or diff3
        """
        return code1 if len(code1) >= len(code2) else code2
    
    def _merge_vector_clocks(self, vc1: VectorClock, vc2: VectorClock) -> VectorClock:
        """Merge vector clocks (take max of each counter)"""
        merged = VectorClock()
        merged.merge(vc1)
        merged.merge(vc2)
        return merged


# ==================== DISTRIBUTED HOOK REGISTRY ====================

class DistributedHookRegistry:
    """
    Distributed registry of hooks with conflict detection and resolution
    """
    
    def __init__(self, 
                 node_id: str,
                 resolver: Optional[SDCKConflictResolver] = None,
                 merger: Optional[HookMerger] = None):
        """
        Initialize registry
        
        Args:
            node_id: This node's ID
            resolver: Conflict resolver (default: SDCK-based)
            merger: Version merger (default: CRDT-style)
        """
        self.node_id = node_id
        self.resolver = resolver or SDCKConflictResolver()
        self.merger = merger or HookMerger()
        
        # Hook versions (hook_id -> list of versions)
        self.versions: Dict[str, List[HookVersion]] = {}
        
        # Conflicts
        self.conflicts: List[Conflict] = []
        
        # Vector clock for this node
        self.vector_clock = VectorClock()
        
        logger.info(f"📚 Distributed Hook Registry initialized: {node_id}")
    
    def add_version(self, version: HookVersion) -> Optional[Conflict]:
        """
        Add a hook version
        
        Args:
            version: Version to add
        
        Returns:
            Conflict if detected, None otherwise
        """
        hook_id = version.hook_id
        
        if hook_id not in self.versions:
            self.versions[hook_id] = []
        
        # Check for conflicts
        conflict = self._detect_conflict(version)
        
        if conflict:
            self.conflicts.append(conflict)
            logger.warning(f"⚠️ Conflict detected for {hook_id}")
            
            # Attempt automatic resolution
            winner = self.resolver.resolve(conflict)
            if winner:
                # Replace all versions with winner
                self.versions[hook_id] = [winner]
                logger.info(f"✅ Conflict auto-resolved for {hook_id}")
        else:
            # No conflict - add version
            self.versions[hook_id].append(version)
            logger.debug(f"📝 Version added: {hook_id} from {version.node_id}")
        
        # Update vector clock
        self.vector_clock.merge(version.vector_clock)
        
        return conflict if (conflict and not conflict.resolved) else None
    
    def _detect_conflict(self, new_version: HookVersion) -> Optional[Conflict]:
        """
        Detect conflict with existing versions
        
        Returns:
            Conflict if detected, None otherwise
        """
        hook_id = new_version.hook_id
        existing_versions = self.versions.get(hook_id, [])
        
        if not existing_versions:
            return None
        
        # Check if concurrent with any existing version
        for existing in existing_versions:
            if new_version.vector_clock.concurrent_with(existing.vector_clock):
                # Concurrent = conflict!
                return Conflict(
                    hook_id=hook_id,
                    versions=[existing, new_version]
                )
        
        # Check if causally ordered
        for existing in existing_versions:
            if existing.vector_clock.happens_before(new_version.vector_clock):
                # New version supersedes existing
                self.versions[hook_id].remove(existing)
            elif new_version.vector_clock.happens_before(existing.vector_clock):
                # Existing version is newer - ignore new version
                return None
        
        return None
    
    def get_current_version(self, hook_id: str) -> Optional[HookVersion]:
        """Get current (resolved) version of a hook"""
        versions = self.versions.get(hook_id, [])
        
        if not versions:
            return None
        
        if len(versions) == 1:
            return versions[0]
        
        # Multiple versions - should have been resolved
        # Resolve now
        conflict = Conflict(hook_id=hook_id, versions=versions)
        winner = self.resolver.resolve(conflict)
        
        if winner:
            self.versions[hook_id] = [winner]
            return winner
        
        return None
    
    def get_conflicts(self, resolved: bool = False) -> List[Conflict]:
        """Get all conflicts"""
        return [c for c in self.conflicts if c.resolved == resolved]


# ==================== USAGE EXAMPLE ====================

if __name__ == "__main__":
    print("="*60)
    print("SDCK-BASED CONFLICT RESOLUTION - DEMO")
    print("="*60)
    
    # Create registry
    registry = DistributedHookRegistry(node_id="node1")
    
    # Create two concurrent versions (conflict!)
    version1 = HookVersion(
        hook_id="debug_hook",
        node_id="node1",
        code='print("Version 1")',
        g1_code_impact=0.5,
        g2_stability=0.5,
        g3_energy=0.5,
        force_class=ForceClass.ALLY.value,
        decision=DecisionCode.AMPLIFY.value
    )
    version1.vector_clock.increment("node1")
    
    version2 = HookVersion(
        hook_id="debug_hook",
        node_id="node2",
        code='print("Version 2")',
        g1_code_impact=0.3,
        g2_stability=0.3,
        g3_energy=-0.5,  # Energy drain!
        force_class=ForceClass.PARASITE.value,
        decision=DecisionCode.ISOLATE.value
    )
    version2.vector_clock.increment("node2")
    
    print("\n🔀 Adding concurrent versions...")
    print(f"   v1: {version1.force_class} (node1)")
    print(f"   v2: {version2.force_class} (node2)")
    
    # Add versions
    conflict1 = registry.add_version(version1)
    conflict2 = registry.add_version(version2)
    
    # Check result
    current = registry.get_current_version("debug_hook")
    print(f"\n✅ Resolved version:")
    print(f"   Winner: {current.node_id}")
    print(f"   Force Class: {current.force_class}")
    print(f"   Reason: ALLY > PARASITE (SDCK priority)")
    
    print("\n" + "="*60)
    print("✅ SDCK CONFLICT RESOLUTION WORKING!")
    print("="*60)
