#!/bin/bash
# Neural Hooks v3.0 - Quick Install Script
# Usage: ./install.sh

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║           ⚡ Neural Hooks v3.0 - Installation ⚡              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python found: $(python3 --version)"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip3 install -q -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Make launcher executable
chmod +x neural_hooks.py

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                  ✅ Installation Complete!                    ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "Usage:"
echo "  python3 neural_hooks.py              # Start GUI"
echo "  python3 neural_hooks.py --cli        # Interactive CLI"
echo "  python3 neural_hooks.py --demo       # Run demo"
echo "  python3 neural_hooks.py --status     # Quick status"
echo ""
