#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║   ⚡ NEURAL HOOKS v3.0 - UNIFIED LAUNCHER ⚡                                 ║
║                                                                              ║
║   One command to rule them all. No configuration needed.                     ║
║                                                                              ║
║   Usage:                                                                     ║
║       python neural_hooks.py                    # Start GUI automatically    ║
║       python neural_hooks.py --cli              # Interactive CLI mode       ║
║       python neural_hooks.py --status           # Quick status check         ║
║       python neural_hooks.py --install <file>   # Install a hook file        ║
║       python neural_hooks.py --demo             # Run demo with test hooks   ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import sys
import os
import subprocess
import argparse
import json
import time
from pathlib import Path

# ==============================================================================
# AUTO-SETUP: Detect and configure everything automatically
# ==============================================================================

SCRIPT_DIR = Path(__file__).parent.resolve()
sys.path.insert(0, str(SCRIPT_DIR))

# Colors for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'

def print_banner():
    """Print the Neural Hooks banner"""
    print(f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║   {Colors.BOLD}⚡ NEURAL HOOKS v3.0 - Production Runtime Code Extension ⚡{Colors.END}{Colors.CYAN}                  ║
║                                                                              ║
║   "Latency is a feature, a bug is a failure"                                 ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝{Colors.END}
""")

def success(msg): print(f"{Colors.GREEN}✅ {msg}{Colors.END}")
def error(msg): print(f"{Colors.RED}❌ {msg}{Colors.END}", file=sys.stderr)
def info(msg): print(f"{Colors.BLUE}ℹ️  {msg}{Colors.END}")
def warning(msg): print(f"{Colors.YELLOW}⚠️  {msg}{Colors.END}")
def step(num, msg): print(f"{Colors.CYAN}[{num}/5]{Colors.END} {msg}")

# ==============================================================================
# STEP 1: Check Python Version
# ==============================================================================

def check_python():
    """Check Python version compatibility"""
    version = sys.version_info
    if version < (3, 8):
        error("Python 3.8+ required")
        sys.exit(1)
    success(f"Python {version.major}.{version.minor}.{version.micro} detected")
    return True

# ==============================================================================
# STEP 2: Auto-Install Dependencies
# ==============================================================================

REQUIRED_PACKAGES = {
    'flask': 'Flask>=2.0.0',
    'flask_cors': 'flask-cors>=3.0.0',
}

def check_and_install_deps():
    """Automatically install missing dependencies"""
    step(2, "Checking dependencies...")

    missing = []
    for module, package in REQUIRED_PACKAGES.items():
        try:
            __import__(module)
            success(f"{module} already installed")
        except ImportError:
            missing.append(package)

    if missing:
        info(f"Installing missing packages: {', '.join(missing)}")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-q"] + missing,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            success("Dependencies installed successfully")
        except subprocess.CalledProcessError as e:
            error(f"Failed to install dependencies: {e}")
            print(f"   Run manually: pip install {' '.join(missing)}")
            sys.exit(1)
    else:
        success("All dependencies satisfied")

# ==============================================================================
# STEP 3: Auto-Configure Environment
# ==============================================================================

CONFIG_DIR = Path.home() / ".neural_hooks"
CONFIG_FILE = CONFIG_DIR / "config.json"

def auto_configure():
    """Automatically configure Neural Hooks environment"""
    step(3, "Configuring environment...")

    # Create config directory
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Default configuration
    default_config = {
        "version": "3.0.0",
        "initialized": True,
        "auto_start_gui": True,
        "default_port": 5000,
        "strict_mode": True,
        "hook_timeout": 5.0,
        "max_hooks": 1000,
        "max_history": 10000,
        "jit_cache_size": 1000,
        "enable_profiling": True,
        "persistence_enabled": True,
        "first_run": True,
    }

    # Load or create config
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
            # Merge with defaults
            for key, value in default_config.items():
                if key not in config:
                    config[key] = value
            success("Configuration loaded")
        except:
            config = default_config
            warning("Using default configuration")
    else:
        config = default_config
        info("Creating new configuration")

    # Save config
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

    success(f"Configuration saved to {CONFIG_FILE}")
    return config

# ==============================================================================
# STEP 4: Initialize Runtime
# ==============================================================================

def init_runtime(config):
    """Initialize the Neural Hooks runtime"""
    step(4, "Initializing runtime...")

    from core import get_global_runtime, NeuralHookRuntime
    from core.runtime_v3 import RuntimeConfig, initialize_runtime

    # Create runtime config from user config
    runtime_config = RuntimeConfig(
        strict_mode=config.get('strict_mode', True),
        hook_timeout_seconds=config.get('hook_timeout', 5.0),
        max_active_hooks=config.get('max_hooks', 1000),
        max_hook_history=config.get('max_history', 10000),
        jit_cache_size=config.get('jit_cache_size', 1000),
        enable_profiling=config.get('enable_profiling', True),
        persistence_enabled=config.get('persistence_enabled', True),
    )

    # Initialize
    runtime = initialize_runtime(runtime_config)

    success("Runtime initialized")
    return runtime

# ==============================================================================
# STEP 5: Start Services
# ==============================================================================

def start_gui_server(port=5000, debug=False):
    """Start the GUI web server"""
    step(5, f"Starting GUI server on port {port}...")

    from gui.gui_server import app

    info(f"Opening http://localhost:{port}")
    info("Press Ctrl+C to stop")

    # Try to open browser automatically
    try:
        import webbrowser
        webbrowser.open(f"http://localhost:{port}")
    except:
        pass

    app.run(host='0.0.0.0', port=port, debug=debug)

def start_cli_interactive():
    """Start interactive CLI mode"""
    print()
    print(f"{Colors.BOLD}Neural Hooks Interactive CLI{Colors.END}")
    print("Type 'help' for commands, 'exit' to quit")
    print()

    from core import get_global_runtime, SDCKHookAnalyzer

    runtime = get_global_runtime()
    analyzer = SDCKHookAnalyzer()

    while True:
        try:
            cmd = input(f"{Colors.CYAN}nhooks>{Colors.END} ").strip()

            if not cmd:
                continue

            parts = cmd.split()
            action = parts[0].lower()

            if action == 'exit' or action == 'quit':
                print("Goodbye!")
                break

            elif action == 'help':
                print("""
Commands:
  status              - Show runtime status
  list                - List active hooks
  analyze <code>      - Analyze code with SDCK
  install <module> <func> <code>  - Install a hook
  remove <hook_id>    - Remove a hook
  demo                - Run demo hooks
  clear               - Clear screen
  exit                - Quit CLI
                """)

            elif action == 'status':
                stats = runtime.get_statistics()
                print(f"\nActive Hooks: {stats.get('active_hooks', 0)}")
                print(f"Hooks Installed: {stats.get('hooks_installed', 0)}")
                print(f"Executions: {stats.get('executions', 0)}")
                print(f"Functions Wrapped: {stats.get('functions_wrapped', 0)}")

            elif action == 'list':
                hooks = runtime.list_hooks()
                if hooks:
                    print(f"\n{'ID':<16} {'Module':<20} {'Function':<15} {'Class':<10}")
                    print("-" * 70)
                    for hook in hooks:
                        print(f"{hook.id[:16]:<16} {hook.hook_point.module_name:<20} "
                              f"{hook.hook_point.function_name:<15} {hook.analysis.force_class.value:<10}")
                else:
                    print("No hooks installed")

            elif action == 'analyze':
                if len(parts) < 2:
                    print("Usage: analyze <code>")
                    continue
                code = ' '.join(parts[1:])
                analysis = analyzer.analyze_hook_code(code)
                print(f"\nForce Class: {analysis.force_class.value}")
                print(f"Decision: {analysis.decision.value}")
                print(f"Risk Level: {analysis.get_risk_level()}")

            elif action == 'clear':
                os.system('clear' if os.name != 'nt' else 'cls')

            elif action == 'demo':
                run_demo()

            else:
                print(f"Unknown command: {action}")

        except KeyboardInterrupt:
            print("\nUse 'exit' to quit")
        except Exception as e:
            error(f"Error: {e}")

def run_demo():
    """Run a demo with test hooks"""
    print()
    print(f"{Colors.BOLD}Running Neural Hooks Demo...{Colors.END}")
    print()

    from core import get_global_runtime, HookPoint, HookType

    runtime = get_global_runtime()

    # Create a test module
    import types
    test_module = types.ModuleType("demo_module")

    def greet(name):
        return f"Hello, {name}!"

    test_module.greet = greet
    sys.modules["demo_module"] = test_module

    info("Created demo_module with greet() function")

    # Install a BEFORE hook
    info("Installing BEFORE hook (logging)...")
    hook1 = runtime.install_hook_from_code(
        HookPoint("demo_module", "greet", HookType.BEFORE),
        'print(f"[BEFORE] greet() called with: {args}")'
    )
    if hook1:
        success(f"Hook installed: {hook1[:16]}")

    # Install an AFTER hook
    info("Installing AFTER hook (timing)...")
    hook2 = runtime.install_hook_from_code(
        HookPoint("demo_module", "greet", HookType.AFTER),
        'print(f"[AFTER] Result: {_result}")'
    )
    if hook2:
        success(f"Hook installed: {hook2[:16]}")

    # Test the hooked function
    print()
    info("Testing hooked function:")
    print(f"   demo_module.greet('World') = {test_module.greet('World')}")
    print()

    # Show status
    stats = runtime.get_statistics()
    info(f"Hooks active: {stats.get('active_hooks', 0)}")
    info(f"Total executions: {stats.get('executions', 0)}")

# ==============================================================================
# MAIN ENTRY POINT
# ==============================================================================

def main():
    """Main entry point - handles all modes automatically"""

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Neural Hooks v3.0 - Unified Launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python neural_hooks.py              # Start GUI (default)
  python neural_hooks.py --cli        # Interactive CLI mode
  python neural_hooks.py --status     # Quick status check
  python neural_hooks.py --demo       # Run demo with test hooks
  python neural_hooks.py --port 8080  # Use custom port for GUI
        """
    )

    parser.add_argument('--cli', action='store_true', help='Interactive CLI mode')
    parser.add_argument('--status', action='store_true', help='Quick status check')
    parser.add_argument('--demo', action='store_true', help='Run demo')
    parser.add_argument('--port', type=int, default=5000, help='GUI server port')
    parser.add_argument('--debug', action='store_true', help='Debug mode')
    parser.add_argument('--install', metavar='FILE', help='Install a hook file')

    args = parser.parse_args()

    # Print banner
    print_banner()

    # Step 1: Check Python
    check_python()

    # Step 2: Install dependencies
    check_and_install_deps()

    # Step 3: Configure
    config = auto_configure()

    # Handle different modes
    if args.status:
        # Quick status only
        from core import get_global_runtime
        runtime = get_global_runtime()
        stats = runtime.get_statistics()
        print()
        print(f"{Colors.BOLD}Runtime Status:{Colors.END}")
        print(f"  Active Hooks: {stats.get('active_hooks', 0)}")
        print(f"  Hooks Installed: {stats.get('hooks_installed', 0)}")
        print(f"  Executions: {stats.get('executions', 0)}")
        print(f"  Functions Wrapped: {stats.get('functions_wrapped', 0)}")
        return

    elif args.demo:
        # Run demo
        run_demo()
        return

    elif args.cli:
        # Interactive CLI
        init_runtime(config)
        start_cli_interactive()
        return

    elif args.install:
        # Install hook file
        init_runtime(config)
        info(f"Installing hook from: {args.install}")
        # TODO: Implement file installation
        return

    else:
        # Default: Start GUI
        init_runtime(config)
        start_gui_server(port=args.port, debug=args.debug)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        info("Interrupted by user")
        sys.exit(0)
    except Exception as e:
        error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
