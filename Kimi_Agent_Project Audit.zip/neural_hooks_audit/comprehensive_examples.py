"""
NEURAL HOOKS v2.0 - COMPREHENSIVE EXAMPLES
===========================================

This file demonstrates all major features of the SDCK-powered
Neural Hooks system with real-world use cases.

Author: Samet (SATEN)
Version: 2.0
"""

import sys
import time
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core import (
    get_global_runtime, HookPoint, HookType,
    ForceClass, DecisionCode, SDCKHookAnalyzer
)


# ==================== EXAMPLE MODULE ====================
# This simulates the "target" code we want to extend

class DataProcessor:
    """Example class with methods we'll hook into"""
    
    def process_data(self, data: list) -> dict:
        """Process a list of items"""
        if not data:
            return {'count': 0, 'items': []}
        
        processed = [item.upper() if isinstance(item, str) else str(item) 
                    for item in data]
        
        return {
            'count': len(processed),
            'items': processed
        }
    
    def expensive_operation(self, n: int) -> int:
        """Simulate expensive computation"""
        time.sleep(0.1)  # Simulate work
        return n * n


# ==================== EXAMPLE 1: DEBUG LOGGING ====================

def example_debug_logging():
    """
    Add debug logging to existing function WITHOUT modifying source
    """
    print("\n" + "="*60)
    print("EXAMPLE 1: DEBUG LOGGING")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Install debug hook
    debug_hook = """
print(f"🔍 [DEBUG] process_data called")
print(f"   Args: {args}")
print(f"   Kwargs: {kwargs}")
"""
    
    hook_id = runtime.install_hook_from_code(
        HookPoint(
            module_name="__main__",
            function_name="process_data",
            hook_type=HookType.BEFORE,
            priority=10
        ),
        debug_hook,
        purpose="Debug logging"
    )
    
    print(f"✅ Installed debug hook: {hook_id}\n")
    
    # Test the hooked function
    processor = DataProcessor()
    result = processor.process_data(['hello', 'world'])
    
    print(f"\n📊 Result: {result}")
    print(f"📈 Stats: {runtime.get_statistics()}")


# ==================== EXAMPLE 2: INPUT VALIDATION ====================

def example_input_validation():
    """
    Add input validation WITHOUT touching original code
    """
    print("\n" + "="*60)
    print("EXAMPLE 2: INPUT VALIDATION")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Validation hook
    validation_hook = """
# Validate input
if not args or not isinstance(args[0], list):
    raise ValueError("process_data requires a list as first argument")

if not args[0]:
    print("⚠️ [WARNING] Empty list provided")

# Let original function proceed
return (args, kwargs)  # Return modified args/kwargs
"""
    
    hook_id = runtime.install_hook_from_code(
        HookPoint(
            module_name="__main__",
            function_name="process_data",
            hook_type=HookType.BEFORE,
            priority=5  # Higher priority = runs first
        ),
        validation_hook,
        purpose="Input validation"
    )
    
    # Get hook details
    hook = runtime.get_hook(hook_id)
    print(f"✅ Installed validation hook: {hook_id}")
    print(f"   Force Class: {hook.analysis.force_class.value}")
    print(f"   Decision: {hook.analysis.decision.value}")
    print(f"   Risk: {hook.get_risk_summary()}")
    
    # Test with valid input
    processor = DataProcessor()
    print("\n🧪 Test 1: Valid input")
    result = processor.process_data(['test'])
    print(f"   Result: {result}")
    
    # Test with empty input
    print("\n🧪 Test 2: Empty list")
    result = processor.process_data([])
    print(f"   Result: {result}")
    
    # Test with invalid input (will raise error)
    print("\n🧪 Test 3: Invalid input (should fail)")
    try:
        result = processor.process_data("not a list")
    except ValueError as e:
        print(f"   ✅ Validation worked: {e}")


# ==================== EXAMPLE 3: PERFORMANCE MONITORING ====================

def example_performance_monitoring():
    """
    Monitor function execution time WITHOUT code changes
    """
    print("\n" + "="*60)
    print("EXAMPLE 3: PERFORMANCE MONITORING")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Performance monitoring hook
    perf_hook = """
import time

start_time = time.perf_counter()

# Execute original
result = original_fn(*args, **kwargs)

end_time = time.perf_counter()
elapsed = end_time - start_time

# Log if slow
if elapsed > 0.05:  # 50ms threshold
    print(f"⏱️ [PERF] expensive_operation took {elapsed:.3f}s")

return result
"""
    
    hook_id = runtime.install_hook_from_code(
        HookPoint(
            module_name="__main__",
            function_name="expensive_operation",
            hook_type=HookType.AROUND
        ),
        perf_hook,
        force=True,  # Bypass strict mode for demo
        purpose="Performance monitoring"
    )
    
    # Analyze the hook
    hook = runtime.get_hook(hook_id)
    analyzer = SDCKHookAnalyzer()
    print(f"✅ Installed perf hook: {hook_id}")
    print(f"   SDCK Analysis:")
    print(f"   - g1 (code impact):  {hook.analysis.g1_code_impact:+.3f}")
    print(f"   - g2 (stability):    {hook.analysis.g2_stability:+.3f}")
    print(f"   - g3 (energy):       {hook.analysis.g3_energy:+.3f}")
    print(f"   - Class: {hook.analysis.force_class.value}")
    print(f"   - Risk: {hook.analysis.get_risk_level()}")
    
    # Test
    processor = DataProcessor()
    print("\n🧪 Running expensive operation (will be monitored)...")
    result = processor.expensive_operation(10)
    print(f"   Result: {result}")


# ==================== EXAMPLE 4: CACHING/MEMOIZATION ====================

def example_caching():
    """
    Add caching to expensive function WITHOUT modifying it
    """
    print("\n" + "="*60)
    print("EXAMPLE 4: AUTOMATIC CACHING")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Caching hook
    cache_hook = """
# Check if we have cached result
cache_key = f"{args}_{kwargs}"
if hasattr(original_fn, '_cache'):
    if cache_key in original_fn._cache:
        print(f"💾 [CACHE HIT] Returning cached result")
        return original_fn._cache[cache_key]

# Execute original
result = original_fn(*args, **kwargs)

# Cache the result
if not hasattr(original_fn, '_cache'):
    original_fn._cache = {}
original_fn._cache[cache_key] = result

print(f"💾 [CACHE MISS] Cached new result")
return result
"""
    
    hook_id = runtime.install_hook_from_code(
        HookPoint(
            module_name="__main__",
            function_name="expensive_operation",
            hook_type=HookType.AROUND
        ),
        cache_hook,
        force=True,  # Bypass strict mode for demo
        purpose="Result caching"
    )
    
    hook = runtime.get_hook(hook_id)
    print(f"✅ Installed cache hook: {hook_id}")
    print(f"   Energy efficiency (g3): {hook.analysis.g3_energy:+.3f}")
    print(f"   (Positive = performance gain)")
    
    # Test caching
    processor = DataProcessor()
    
    print("\n🧪 First call (cache miss):")
    start = time.perf_counter()
    result1 = processor.expensive_operation(5)
    time1 = time.perf_counter() - start
    print(f"   Result: {result1}, Time: {time1:.3f}s")
    
    print("\n🧪 Second call (cache hit):")
    start = time.perf_counter()
    result2 = processor.expensive_operation(5)
    time2 = time.perf_counter() - start
    print(f"   Result: {result2}, Time: {time2:.3f}s")
    
    print(f"\n⚡ Speedup: {time1/time2:.1f}x faster!")


# ==================== EXAMPLE 5: SDCK CLASSIFICATION ====================

def example_sdck_classification():
    """
    Demonstrate SDCK classification of different hook types
    """
    print("\n" + "="*60)
    print("EXAMPLE 5: SDCK CLASSIFICATION")
    print("="*60)
    
    analyzer = SDCKHookAnalyzer()
    
    test_hooks = {
        'Safe Enhancement': """
# Add validation
if len(args) > 0 and hasattr(args[0], '__len__'):
    if len(args[0]) > 1000:
        print("⚠️ Large input detected")
""",
        
        'Performance Drain': """
import time
time.sleep(1)  # BAD: Blocks execution
""",
        
        'Dangerous Code': """
exec("import os; os.system('rm -rf /')")  # VERY BAD!
""",
        
        'Good Optimization': """
# Early exit optimization
if not args or len(args[0]) == 0:
    return {'count': 0, 'items': []}  # Skip expensive processing
"""
    }
    
    print("\n📊 Analyzing different hook types:\n")
    
    for name, code in test_hooks.items():
        analysis = analyzer.analyze_hook_code(code)
        
        print(f"🔬 {name}")
        print(f"   g1 (code impact):  {analysis.g1_code_impact:+.3f}")
        print(f"   g2 (stability):    {analysis.g2_stability:+.3f}")
        print(f"   g3 (energy):       {analysis.g3_energy:+.3f}")
        print(f"   → Force Class: {analysis.force_class.value}")
        print(f"   → Decision: {analysis.decision.value}")
        print(f"   → Risk Level: {analysis.get_risk_level()}")
        print(f"   → Safe to amplify: {analysis.is_safe_to_amplify()}")
        print()


# ==================== EXAMPLE 6: ENERGY DRAIN PROTECTION ====================

def example_energy_drain_protection():
    """
    Demonstrate Energy Drain Law enforcement
    """
    print("\n" + "="*60)
    print("EXAMPLE 6: ENERGY DRAIN PROTECTION")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Try to install an energy-draining hook
    bad_hook = """
import time
# This will drain energy (g3 < 0)
time.sleep(10)
"""
    
    print("🧪 Attempting to install energy-draining hook...")
    
    hook_id = runtime.install_hook_from_code(
        HookPoint(
            module_name="__main__",
            function_name="process_data",
            hook_type=HookType.BEFORE
        ),
        bad_hook
    )
    
    if hook_id:
        hook = runtime.get_hook(hook_id)
        print(f"✅ Hook installed: {hook_id}")
        print(f"   Force Class: {hook.analysis.force_class.value}")
        print(f"   Decision: {hook.analysis.decision.value}")
        print(f"\n🔒 Energy Drain Law ENFORCED:")
        print(f"   - Hook has g3 = {hook.analysis.g3_energy:.3f} (energy drain)")
        print(f"   - Classified as: {hook.analysis.force_class.value}")
        print(f"   - Decision: {hook.analysis.decision.value} (NOT amplified!)")
        print(f"   - This hook will NEVER be propagated globally")
        print(f"\n✅ Mathematical guarantee: Energy-draining hooks cannot spread!")


# ==================== EXAMPLE 7: HOOK STATISTICS ====================

def example_statistics():
    """
    Show runtime statistics and hook management
    """
    print("\n" + "="*60)
    print("EXAMPLE 7: RUNTIME STATISTICS")
    print("="*60)
    
    runtime = get_global_runtime()
    
    # Install several hooks
    hooks = []
    for i in range(5):
        hook_id = runtime.install_hook_from_code(
            HookPoint(
                module_name="__main__",
                function_name="process_data",
                hook_type=HookType.BEFORE,
                priority=i*10
            ),
            f'print(f"Hook {i} executing")',
            purpose=f"Test hook {i}"
        )
        hooks.append(hook_id)
    
    # Get statistics
    stats = runtime.get_statistics()
    
    print("\n📊 Runtime Statistics:")
    print(f"   Total hooks installed: {stats['hooks_installed']}")
    print(f"   Active hooks: {stats['active_hooks']}")
    print(f"   Hooks rejected: {stats['hooks_rejected']}")
    print(f"   Energy violations prevented: {stats['energy_violations_prevented']}")
    print(f"   Functions wrapped: {stats['functions_wrapped']}")
    
    print(f"\n📋 Hooks by class:")
    for force_class, count in stats['hooks_by_class'].items():
        print(f"   - {force_class}: {count}")
    
    # List all hooks
    print(f"\n📝 All installed hooks:")
    all_hooks = runtime.list_hooks()
    for hook in all_hooks:
        print(f"   - {hook.id}: {hook.hook_point.hook_type} @ priority {hook.hook_point.priority}")
        print(f"     Class: {hook.analysis.force_class.value}, Decision: {hook.analysis.decision.value}")


# ==================== MAIN ====================

def main():
    """Run all examples"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║         NEURAL HOOKS v2.0 - COMPREHENSIVE EXAMPLES           ║
║                                                              ║
║              SDCK-Powered Runtime Code Extension             ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
""")
    
    # Run examples
    example_debug_logging()
    example_input_validation()
    example_performance_monitoring()
    example_caching()
    example_sdck_classification()
    example_energy_drain_protection()
    example_statistics()
    
    print("\n" + "="*60)
    print("✅ ALL EXAMPLES COMPLETED")
    print("="*60)
    print("\nKey Takeaways:")
    print("1. ✅ Hooks can be added WITHOUT modifying source code")
    print("2. ✅ SDCK provides MATHEMATICAL SAFETY GUARANTEES")
    print("3. ✅ Energy Drain Law prevents performance degradation")
    print("4. ✅ Automatic classification and risk assessment")
    print("5. ✅ Production-ready with comprehensive error handling")
    print("\n🚀 Neural Hooks v2.0 is PRODUCTION READY!")


if __name__ == "__main__":
    main()
