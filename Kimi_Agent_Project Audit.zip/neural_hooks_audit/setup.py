#!/usr/bin/env python3
"""
Neural Hooks v3.0 - Setup Script
================================

Install with: pip install .
Or run directly: python setup.py install
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "docs" / "README.md"
if readme_file.exists():
    with open(readme_file, 'r', encoding='utf-8') as f:
        long_description = f.read()
else:
    long_description = "Neural Hooks v3.0 - Production Runtime Code Extension"

setup(
    name="neural-hooks",
    version="3.0.0",
    author="Neural Hooks Production System",
    description="Production Runtime Code Extension with SDCK Classification",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/neural-hooks/neural-hooks",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Flask>=2.0.0",
        "flask-cors>=3.0.0",
    ],
    entry_points={
        'console_scripts': [
            'neural-hooks=neural_hooks:main',
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
